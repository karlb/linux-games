#include "inputimpl.h"

/* 
 *  Constructs a inputImpl which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
inputImpl::inputImpl( QWidget* parent, QString *newname, const char* name, WFlags fl )
    : input( parent, name, true, fl )
{

    namep = newname;

}

/*  
 *  Destroys the object and frees any allocated resources
 */
inputImpl::~inputImpl()
{
    // no need to delete child widgets, Qt does it all for us
}

/* 
 * public slot
 */
void inputImpl::setName(const QString& newname)
{
	*namep = newname;
}

