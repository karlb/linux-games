#include <qpe/config.h>
#include <qinputdialog.h> 
#include <qmessagebox.h>

#include "highscore.h"
#include "inputimpl.h"
#include <stdio.h>

HighScore::HighScore(QWidget *newparent, char *appName): Config(QString(appName), User)
{
	parent = newparent;
	QString text;
	setGroup("score");

	if (!hasKey("P0")) {
		puts("Generating new HighScore list");
		name[0] = "Sam Wonder";
		name[1] = "Tim Super";
		name[2] = "Frank V. Good";
		name[3] = "Chris Good";
		name[4] = "Quite Good";
		name[5] = "Not S. O. Good";
		name[6] = "Bill Rather Bad";
		name[7] = "Mr. Bad";
		name[8] = "Stef Murky";
		name[9] = "Stef Murky";
		for (int i=0; i<10; i++)
			score[9-i] = i*5 + 30;
		writeScore();
	} else {
		for (int i=0; i<10; i++) {
			text.sprintf("P%d", i);
			name[i] = readEntry(text);
			text.sprintf("S%d", i);
			score[i] = readNumEntry(text);
		}
	}
	
}

HighScore::~HighScore()
{
	writeScore();
}

void HighScore::showScore()
{
	QString text;
	
	QMessageBox *box;
	box = new QMessageBox(parent);
	text = "<center><b>HighScores</b></center><br><TABLE CELLSPACING=\"0\">";
	for (int i=0; i<10; i++) {
		QString s;
		s.sprintf("<TR><TD align=\"right\">%d.</TD><TD>%s</TD><TD align=\"right\">%7d</TD></TR>", i+1, (const char *)name[i], score[i]);
		text += s;
	}
	text += "</TABLE>";
	box->setText(text);
	box->exec();
}

void HighScore::writeScore()
{
	QString text;

	clearGroup();

	for (int i=0; i<10; i++) {
		text.sprintf("P%d", i);
		writeEntry(text, name[i]);
		text.sprintf("S%d", i);
		writeEntry(text, score[i]);
	}
}

void HighScore::addScore(int newscore)
{
	if (newscore < score[9])
		return;

	QString newname;

	inputImpl *input;
	input = new inputImpl(parent, &newname);
	input->exec();
	
	int i = 9;
	while ( score[i-1] < newscore && i > 0) {
		score[i] = score[i-1];
		name[i] = name[i-1];
		i--;
	}
	name[i] = newname;
	score[i] = newscore;
	
	writeScore();
	showScore();
}





