#ifndef ZNUMBERS_WINDOW_H
#define ZNUMBERS_WINDOW_H
#include <qmainwindow.h>
#include "board.h"

class AppWindow : public QMainWindow
{
	Q_OBJECT
public:
	AppWindow( QWidget* parent = 0, const char* name = 0, WFlags f = WType_TopLevel );
	
protected:
	void paintEvent ( QPaintEvent * );

private slots:
	void menuSelected(int);
	void showScore(int);

private:

	enum MenuItems
	{
		PAUSE_GAME,
		UNPAUSE_GAME,
		EXIT,
		ABOUT,
		RULES,
		HIGHSCORE,
		
		LEVELNUM
	};

	QPopupMenu* appMenu;
	QPopupMenu* levelMenu;

	Board *board;
	int score;
};

#endif
