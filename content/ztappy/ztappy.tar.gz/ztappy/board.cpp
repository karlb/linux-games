#include "board.h"
#include <qpainter.h>
#include <qmessagebox.h> 
#include <qpe/resource.h>

const char xblocks = 5, yblocks = 5, blockTypes = 6;
const int  selectTime = 2000, faultTime = 3000;

Board::Board(QWidget* parent, const char* name, WFlags f ): QWidget(parent,name,f)
{
	char filename[50];
	for (int i=0; i<blockTypes; i++) {
		sprintf(filename, "p%d", i+1);
		blockPic[i] = loadPixmap(filename);
	}

	emptyPic = loadPixmap("ground");
	selectPic = loadPixmap("select");
	faultPic = loadPixmap("fault");
	middlePic = loadPixmap("middle");
	
	buffer = new QPixmap(240, 265);
	
	highscore = new HighScore(this, "zTappy");

	blockWidth  = emptyPic.width();
	blockHeight = emptyPic.height();
	
	newBlockTimer = new QTimer(this, "newBlockTimer");
	newBlockTimer->start(interval);
	connect(newBlockTimer, SIGNAL(timeout()), SLOT(newBlock()));

	middleTimer = new QTimer(this, "middleTimer");
	middleTimer->start(6000);
	connect(middleTimer, SIGNAL(timeout()), SLOT(newMiddleBlock()));
	
	selectTimer = new QTimer(this, "selectTimer");
	connect(selectTimer, SIGNAL(timeout()), SLOT(unselectAll()));

	faultTimer = new QTimer(this, "faultTimer");
	connect(faultTimer, SIGNAL(timeout()), SLOT(removeFault()));

	startLevel(1);
}

Board::~Board()
{
	delete highscore;
}

void Board::removeFault()
{
	fault = false;
}

void Board::newBlock()
{
	if (!finished()) {
		int x, y;
		do {
			x = rand() % 5;
			y = rand() % 5;
		} while (map[x][y]);
		
		map[x][y] = rand() % blockTypes + 1;
		paintEvent(NULL);

		interval -= (interval*interval)/100000;
		newBlockTimer->changeInterval(int(interval));

	} else {
		// Looser
		stop();
		lost = true;
		QMessageBox *box;
		box = new QMessageBox(this, "endBox");
		char text[100];
		sprintf(text, "<center><b>Game Over</b><BR><BR>Your score: %d</center>", score);
		box->setText(text);
		box->exec();
		highscore->addScore(score);
	}
}

void Board::newMiddleBlock()
{
	int newMiddle;
	do {
		newMiddle = rand() % blockTypes + 1;
	} while ((map[2][2] == newMiddle) || (newMiddle == selectedType));
		
	map[2][2] = newMiddle;
	paintEvent(NULL);

	middleTimer->changeInterval(int(interval*3));
}

void Board::start()
{
	if (lost)
		return;

	middleTimer->start(int(interval*3));
	newBlockTimer->start(int(interval));
}

void Board::stop()
{
	middleTimer->stop();
	newBlockTimer->stop();
}

void Board::startLevel(int difficulty)
{
	selectedType = -1;
	score = 0;
	emit showScore(0);
	unselectAll();
	interval = 3000 - 1000*difficulty;
	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			map[x][y] = 0;

	map[2][2] = rand() % blockTypes + 1;
	paintEvent(NULL);
	lost = false;
	start();
}

void Board::paintEvent ( QPaintEvent *pe) 
{
	
	QPainter p(buffer);
	p.moveTo(0,0);

	for (int x=0; x<xblocks; x++) {
		for (int y=0; y<yblocks; y++) {
			if (map[x][y] > 0) 
				p.drawPixmap(blockWidth*x, blockHeight*y, blockPic[map[x][y]-1]);
			else {
				p.drawPixmap(blockWidth*x, blockHeight*y, emptyPic);
			}
			
			if (selected[x][y]) {
				p.drawPixmap(blockWidth*x, blockHeight*y, selectPic);
			}
		}
	}

	//if (finished())
	//	p.drawPixmap(width()/2 - wonPic.width()/2, height()/2 - wonPic.height()/2, wonPic);

	if (fault)
		p.drawPixmap(blockWidth*2, blockHeight*2, faultPic);
	else
		p.drawPixmap(blockWidth*2, blockHeight*2, middlePic);
	
	// Screen update
	QPainter final(this);
	final.drawPixmap(0, 0, *buffer);
}

bool Board::allSelected()
{
	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			if ((!selected[x][y]) && (selectedType==map[x][y])
			    &&((x!=2)||(y!=2)))
				return false;
	
	return true;
}

bool Board::finished()
{
	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			if (!map[x][y])
				return false;
	
	return true;
}

void Board::unselectAll()
{
	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			selected[x][y] = 0;

	selectCount = 0;
	selectedType = 0;
}

void Board::deleteAll(int which)
{
	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			if ((map[x][y] == which)&&((x!=2)||(y!=2))) {
				map[x][y] = 0;
				score++;
			}
}


void Board::mousePressEvent ( QMouseEvent *e )
{
	if (finished() || fault)
		return;

	int x = e->x() / blockWidth;
	int y = e->y() / blockHeight;
	
	if ( (x == 2) && (y == 2) )
		return;
		
	if (!map[x][y])
		return;

	if (map[x][y] == map[2][2]) {
		fault = true;
		faultTimer->start(faultTime, true);
		paintEvent(NULL);
		return;
	}
	
	if (selectedType == map[x][y]) {
		selectedType = map[x][y];
		selected[x][y] = 1;
		selectCount++;
	} else if (map[x][y] != 0){
		unselectAll();
		selectedType = map[x][y];
		selected[x][y] = 1;
		selectCount = 1;
		selectTimer->start(selectTime, true);
	}
	
	if ((selectCount > 1) && (allSelected())){
		deleteAll(selectedType);
		selectTimer->stop();
		unselectAll();
		emit showScore(score);
	}

	paintEvent(NULL);
}

QPixmap Board::loadPixmap(char *file)
{
	const char appName[] = "ztappy";
	const char GFX_PATH[] = "ipk/opt/QtPalmtop/pics";

	if (getenv("XAUTHORITY") == NULL) {
		char filename[80];
		sprintf(filename, "%s/%s", appName, file);

		return Resource::loadPixmap(filename);
	} else {
		char filename[80];
		QPixmap *ret;
		ret = new QPixmap;
	
		sprintf(filename, "%s/%s/%s.png", GFX_PATH, appName, file);
		if (!ret->load(filename))
			printf("Couldn't load %s\n",filename);
			
		return *ret;
	}
}

