#include <qpainter.h>
#include <qmenubar.h>
#include <qapplication.h>
#include <qmessagebox.h>

#include "app_window.h"
#include "board.h"

#define str(s) xstr(s)
#define xstr(s) #s
#define appName zTappy

AppWindow::AppWindow( QWidget* parent, const char* name, WFlags f )
	: QMainWindow( parent, name, f )
{
	setCaption(str(appName));
	srand(time(NULL));

	board = new Board(this);
	board->setGeometry(5, 45, 230, 230);
	connect(board, SIGNAL(showScore(int)), SLOT(showScore(int)));
	score = 0;

	QMenuBar *mb=menuBar();

    appMenu = new QPopupMenu;
	appMenu->insertItem( "&About", ABOUT);
	appMenu->insertItem( "&Rules", RULES);
	appMenu->insertSeparator();
	appMenu->insertItem( "&Exit", EXIT);
	mb->insertItem(str(&appName), appMenu);
	connect( appMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
    levelMenu = new QPopupMenu;
	levelMenu->insertItem( "&Pause Game", PAUSE_GAME);
	levelMenu->insertItem( "&Unpause Game", UNPAUSE_GAME);
	levelMenu->insertSeparator();
	levelMenu->insertItem( "&Easy Game", LEVELNUM+0);
	levelMenu->insertItem( "&Normal Game", LEVELNUM+1);
	levelMenu->insertItem( "&Hard Game", LEVELNUM+2);
	levelMenu->insertSeparator();
	levelMenu->insertItem( "&Show HighScores", HIGHSCORE);
	mb->insertItem("&Game", levelMenu);
	connect( levelMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
}

void AppWindow::showScore(int newScore)
{
	score = newScore;
	paintEvent(NULL);
}

void AppWindow::paintEvent ( QPaintEvent * )
{
	QPixmap tpix(width(),height());
	tpix.fill(QColor(199,190,166));
	
	QPainter p(this);
	p.drawPixmap(0,0,tpix);
	
	p.setFont( QFont("helvetica", 20));
	char text[30];
	sprintf(text, "Score: %d", score);
	p.drawText(8, 40, QString(text));
}


void AppWindow::menuSelected(int id)
{
	switch(id) {
		case EXIT:
			close();
		break;
		case ABOUT:
			QMessageBox *abox;
			abox = new QMessageBox(this, "About");
			abox->setText("<center><B>zTappy</B><BR>www.linux-games.com<BR><BR>(c) 2002 by Karl Bartel<BR>This is free Software (GPL)</center>");
			board->stop();
			abox->exec();
			board->start();
		break;
		case RULES:
			QMessageBox *rbox;
			rbox = new QMessageBox(this, "Rules");
			rbox->setText("<center><B>zTappy Rules</B></center><BR><b>Goal:</b> Remove as many blocks as possible.<BR><b>Removing blocks:</b> Select all blocks with the same symbol to remove them. This only works if there is more than one block with this symbol.<BR><b>The middle block:</b> When you try to remove a block with the same symbol as the middle block, you can't select any blocks for a short time.");
			rbox->setMaximumWidth(210);
			board->stop();
			rbox->exec();
			board->start();
		break;
		case PAUSE_GAME:
			board->stop();
		break;
		case UNPAUSE_GAME:
			board->start();
		break;
		case LEVELNUM:
		case LEVELNUM+1:
		case LEVELNUM+2:
			board->startLevel(id-LEVELNUM);
		break;
		case HIGHSCORE:
			board->stop();
			board->highscore->showScore();
			board->start();
		break;
		default:
		break;
	}
}
