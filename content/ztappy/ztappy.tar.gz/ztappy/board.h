#ifndef BOARD_H
#define BOARD_H

#include <qwidget.h>
#include <qbitmap.h>
#include <qtimer.h>
#include <qpoint.h>
#include <qlist.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>
#include <qtimer.h>
#include <qpixmap.h>
#include "highscore/highscore.h"

class Board : public QWidget
{
	Q_OBJECT

public:
	Board(QWidget* parent=0, const char* name=0, WFlags f=0 );
	~Board();
	void startLevel(int difficulty);
	void start();
	void stop();
	HighScore *highscore;

protected:
	void paintEvent ( QPaintEvent * );
	void mousePressEvent ( QMouseEvent * ); 

signals:
	void showScore(int);

private slots: 
	void newBlock();
	void newMiddleBlock();
	void unselectAll();
	void removeFault();

private:
	QPixmap blockPic[6], emptyPic, selectPic, faultPic, middlePic;
	QPixmap *buffer;
	int map[5][5], selected[5][5];
	int blockWidth, blockHeight, selectCount, selectedType, score;
	float interval;
	bool fault, lost;
	QTimer *newBlockTimer, *selectTimer, *middleTimer, *faultTimer;

	void deleteAll(int which);
	bool allSelected();
	bool finished();
	QPixmap loadPixmap(char *file);
};

#endif
