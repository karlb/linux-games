/*  Black-box: guess where the crystals are !                                           
    Copyright (C) 2000 Karl Bartel                                              
                                                                                
    This program is free software; you can redistribute it and/or modify        
    it under the terms of the GNU General Public License as published by        
    the Free Software Foundation; either version 2 of the License, or           
    (at your option) any later version.                                         
                                                                                
    This program is distributed in the hope that it will be useful,             
    but WITHOUT ANY WARRANTY; without even the implied warranty of              
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               
    GNU General Public License for more details.                                
                                                                                
    You should have received a copy of the GNU General Public License           
    along with this program; if not, write to the Free Software                 
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   
                                                                                
    Karl Bartel                                                                 
    Cecilienstr. 14                                                             
    12307 Berlin                                                                
    GERMANY                                                                     
    karlb@gmx.net                                                               
*/                                                                              


// normal includes
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <signal.h>

// X11 includes
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/keysym.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>

// pictures
#include "gfx/box.xpm"
#include "gfx/edge1.xpm"
#include "gfx/edge2.xpm"
#include "gfx/edge3.xpm"
#include "gfx/edge1red.xpm"
#include "gfx/edge2red.xpm"
#include "gfx/edge3red.xpm"
#include "gfx/think.xpm"
#include "gfx/real.xpm"
#include "gfx/new.xpm"
#include "gfx/quit.xpm"
#include "gfx/giveup.xpm"
#include "gfx/won.xpm"
#include "gfx/false.xpm"

typedef struct {
       Pixmap pix;
       int width;
       int height;
} Image;

       Display *display;
       Window window;
       GC whitegc, blackgc, pastegc;
       int difficulty=4,trihigh=1;   //settings

       XEvent event;
       Image box_pic,edge1_pic,edge2_pic,edge3_pic,think_pic;
       Image real_pic, giveup_pic, new_pic, quit_pic, won_pic, false_pic;
       Image edge1red_pic,edge2red_pic,edge3red_pic;
       Image edge1rred_pic,edge2rred_pic,edge3rred_pic;
       int mouse_x, mouse_y, level_num, won_shown;
       int blocksize = 14;
       int xscreen = 160;
       int yscreen = 240;
       char text[80];
       char xline[11];
       char yline[11];
       char think[11][11];
       char real[11][11];


typedef struct {
       int x;
       int y;
       int dir;
} output;

void delay(unsigned long ms)
{
    usleep(ms*1000);
}

void setpix( int X, int Y, int red, int green, int blue)  //sets one Pixel to the screen 
{
    if (red != 0)
	XDrawLine(display, window, whitegc, X, Y, X, Y);
    else
	XDrawLine(display, window, blackgc, X, Y, X, Y);
}

void blit(int Xpos,int Ypos,Image image)  //blits one GIF or BMP from the memory to the screen
{
  XSetClipOrigin(display, pastegc, Xpos, Ypos);
  XCopyArea(display, image.pix, window, pastegc, 0, 0, image.width, image.height, Xpos, Ypos);
}

int abrand(int a,int b)  //random number between a and b (inclusive)
{
  return(a+(rand() % (b-a+1)));
}

GC CreateGC(Display *display, Drawable drawable, unsigned long forecolor, unsigned long backcolor)
{
    XGCValues xgcvalues;
    GC gc;
    
    xgcvalues.foreground = forecolor;
    xgcvalues.background = backcolor;
    gc = XCreateGC(display,drawable,(GCForeground | GCBackground), &xgcvalues);
    
    return(gc);
}


void init_x11()  // sets the video mode
{
  Window rootwindow;
  int screen, black, white;
  XSetWindowAttributes attr;
  XWMHints wmhints;
  char wname[64];
  unsigned long attr_mask;
  struct timeval tp;

  display = XOpenDisplay(NULL);
  if (display == NULL) {
      fprintf(stderr, "Can't connect to display!\n"); exit(1);
  }
    
  screen = DefaultScreen(display);
  rootwindow = RootWindow(display, screen);
    
  /* Get primitive colors: */
  
  white = BlackPixel(display, screen);
  black = WhitePixel(display, screen);
  
  
  /* Open window: */
  
  attr.event_mask = (KeyPressMask | KeyReleaseMask | ButtonPressMask |
		     ButtonReleaseMask | PointerMotionMask |
		     ExposureMask | VisibilityChangeMask);

  attr.border_pixel = black;
  attr.background_pixel = white;
  attr_mask = CWEventMask | CWBackPixel | CWBorderPixel;
  
  window = XCreateWindow(display, rootwindow, 0, 0, xscreen, yscreen, 0,
			 DefaultDepthOfScreen(DefaultScreenOfDisplay(display)),
			 InputOutput, DefaultVisual(display, screen),
			 attr_mask, &attr);


  /* Set input hints and window name (so we appear in the window lists).
     Need to do this because of a bug in VRSM.  Not bad to do anyway, tho */

  wmhints.input = True;
  wmhints.flags |= InputHint;
  XSetWMHints(display, window, &wmhints);

  sprintf(wname, "Black-Box");
  XChangeProperty(display, window, XA_WM_NAME, XA_STRING, 8,
                  PropModeReplace, wname, strlen(wname));

  
  /* Create primitive graphics contexts: */

  whitegc = CreateGC(display, window, white, black);
  blackgc = CreateGC(display, window, black, black);

  pastegc = CreateGC(display, window, white, black);
    
  
  /* Bring window up! */
  
  XMapWindow(display, window);
  XMapRaised(display, window);
  XFlush(display);
  XSync(display, 0);
}

void xshot(int y,int right,int erase) //x right
{
  int x,move;
  for (move=blocksize/2;move<blocksize*3/2;move++)
  {
    if (erase)
    {
      setpix(move+right*blocksize*10,y,0,0,0);
      setpix(move+right*blocksize*10,y+1,0,0,0);
      setpix(move+right*blocksize*10,y-1,0,0,0);
    }
    else
    {
      setpix(move+right*blocksize*10,y,255,0,0);
      setpix(move+right*blocksize*10,y+1,255,0,0);
      setpix(move+right*blocksize*10,y-1,255,0,0);
    }
    if (move % 2==0) delay(1);
    XFlush(display);
    XSync(display, 0);
  }
}

void xshot2(int y,int right,int erase) //x left
{
  int x,move;
  for (move=blocksize*3/2;move>blocksize/2;move--)
  {
    if (erase)
    {
      setpix(move+right*blocksize*10,y,0,0,0);
      setpix(move+right*blocksize*10,y+1,0,0,0);
      setpix(move+right*blocksize*10,y-1,0,0,0);
    }
    else
    {
      setpix(move+right*blocksize*10,y,255,0,0);
      setpix(move+right*blocksize*10,y+1,255,0,0);
      setpix(move+right*blocksize*10,y-1,255,0,0);
    }
    if (move % 2==0) delay(1);
    XFlush(display);
    XSync(display, 0);
  }
}

void yshot(int x,int down,int erase) // y down
{
  int y,move;
  for (move=blocksize/2;move<blocksize*3/2;move++)
  {
    if (erase)
    {
      setpix(x,move+down*blocksize*12,0,0,0);
      setpix(x+1,move+down*blocksize*12,0,0,0);
      setpix(x-1,move+down*blocksize*12,0,0,0);
    }
    else 
    {
      setpix(x,move+down*blocksize*12,255,0,0);
      setpix(x+1,move+down*blocksize*12,255,0,0);
      setpix(x-1,move+down*blocksize*12,255,0,0);
    }
    if (move % 2==0) delay(1);
    XFlush(display);
    XSync(display, 0);
  }
}

void yshot2(int x,int down,int erase)  //y up
{
  int y,move;
  for (move=blocksize*3/2;move>blocksize/2;move--)
  {
    if (erase)
    {
      setpix(x,move+down*blocksize*12,0,0,0);
      setpix(x+1,move+down*blocksize*12,0,0,0);
      setpix(x-1,move+down*blocksize*12,0,0,0);
    }
    else 
    {
      setpix(x,move+down*blocksize*12,255,0,0);
      setpix(x+1,move+down*blocksize*12,255,0,0);
      setpix(x-1,move+down*blocksize*12,255,0,0);
    }
    if (move % 2==0) delay(1);
    XFlush(display);
    XSync(display, 0);
  }
}

void select_shot(int x,int y,int dir,int erase)
{
  if ((dir==1)||(dir==3))
  {
    if (dir==1)
      xshot((y+2)*blocksize,div(x,9).quot,erase);
    if (dir==3)
      xshot2((y+2)*blocksize,div(x,9).quot,erase);
  }
  else
  {
    if (dir==0)
      yshot2((x+2)*blocksize,div(y,11).quot,erase);
    if (dir==2)
      yshot((x+2)*blocksize,div(y,11).quot,erase);
  }
}

output calc_real(int x,int y,int dir)
{
  int end=0;
  output out;
  
  while (!end)
  {
    if (dir==0) 
    {
      if (y==0) {end=1;} else
      if (real[x-1][y-1]==1) {dir=1;} else
      if (real[x][y-1]==1) {dir=3;}
      else {y--;}
    }
    if (dir==1)
    {
      if (x==9) {end=1;} else
      if (real[x][y]==1) {dir=0;} else
      if (real[x][y-1]==1) {dir=2;}
      else {x++;}
    }
    if (dir==2)
    {
      if (y==11) {end=1;} else
      if (real[x][y]==1) {dir=3;} else
      if (real[x-1][y]==1) {dir=1;}
      else {y++;}
    }
    if (dir==3)
    {
      if (x==0) {end=1;} else
      if (real[x-1][y]==1) {dir=0;} else
      if (real[x-1][y-1]==1) {dir=2;}
      else {x--;}
    }
    if ((x>30)||(y>20)||(y<0)||(y<0))
    {
      printf("ERROR: x or y out of range in function hidden, quitting now.\n");
      exit(1);
    }
  }
  out.x=x;
  out.y=y;
  out.dir=dir;
  

  return(out);
}

output calc_think(int x,int y,int dir)
{
  int end=0;
  output out;
  
  while (!end)
  {
    if (dir==0) 
    {
      if (y==0) {end=1;} else
      if (think[x-1][y-1]==1) {dir=1;} else
      if (think[x][y-1]==1) {dir=3;}
      else {y--;}
    }
    if (dir==1)
    {
      if (x==9) {end=1;} else
      if (think[x][y]==1) {dir=0;} else
      if (think[x][y-1]==1) {dir=2;}
      else {x++;}
    }
    if (dir==2)
    {
      if (y==11) {end=1;} else
      if (think[x][y]==1) {dir=3;} else
      if (think[x-1][y]==1) {dir=1;}
      else {y++;}
    }
    if (dir==3)
    {
      if (x==0) {end=1;} else
      if (think[x-1][y]==1) {dir=0;} else
      if (think[x-1][y-1]==1) {dir=2;}
      else {x--;}
    }
    if ((x>30)||(y>20)||(y<0)||(y<0))
    {
      printf("ERROR: x or y out of range in function hidden, quitting now.\n");
      exit(1);
    }
  }
  out.x=x;
  out.y=y;
  out.dir=dir;
  
  return(out);
}

void blit_screen()
{
  int x,y;
  
  won_shown=0;
  blit(0,211,new_pic);
  blit(55,208,giveup_pic);
  blit(105,210,quit_pic);
  if (trihigh)
  {
    edge1red_pic=edge1rred_pic;
    edge2red_pic=edge2rred_pic;
    edge3red_pic=edge3rred_pic;
  }else
  {
    edge1red_pic=edge1_pic;
    edge2red_pic=edge2_pic;
    edge3red_pic=edge3_pic;
  }
  
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      blit(x*blocksize+blocksize*3/2,y*blocksize+blocksize*3/2,box_pic);
    }
  }
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      if (think[x][y])
        {blit(x*blocksize+blocksize*2,y*blocksize+blocksize*2,think_pic);}
    }
  }
  for (x=0;x<=8;x++){
    if ((calc_real(x,0,2).x==calc_think(x,0,2).x)
       &&(calc_real(x,0,2).y==calc_think(x,0,2).y)
       &&(calc_real(x,0,2).dir==calc_think(x,0,2).dir))
    {blit(x*blocksize+blocksize*3/2,0,edge1_pic);}
    else {blit(x*blocksize+blocksize*3/2,0,edge1red_pic);}
  }
  for (y=0;y<=10;y++){
    if ((calc_real(0,y,1).x==calc_think(0,y,1).x)
       &&(calc_real(0,y,1).y==calc_think(0,y,1).y)
       &&(calc_real(0,y,1).dir==calc_think(0,y,1).dir))
    {blit(0,y*blocksize+blocksize*3/2,edge2_pic);}
    else {blit(0,y*blocksize+blocksize*3/2,edge2red_pic);}
  }  
  for (x=0;x<=8;x++){
    if ((calc_real(x,11,0).x==calc_think(x,11,0).x)
       &&(calc_real(x,11,0).y==calc_think(x,11,0).y)
       &&(calc_real(x,11,0).dir==calc_think(x,11,0).dir))
    {blit(x*blocksize+blocksize*3/2,blocksize*14-10,edge3_pic);}
    else {blit(x*blocksize+blocksize*3/2,blocksize*14-10,edge3red_pic);}
  }
}

void hidden(int x,int y,int dir)  //0=up 1=right 2=down 3=left
{
  int end=0,x_in,y_in,dir_in;

  x_in=x;
  y_in=y;  
  dir_in=dir;
  
  select_shot(x,y,dir,0);
  while (!end)
  {
    if (dir==0) 
    {
      if (y==0) {end=1;} else
      if (real[x-1][y-1]==1) {dir=1;} else
      if (real[x][y-1]==1) {dir=3;}
      else {y--;}
    }
    if (dir==1)
    {
      if (x==9) {end=1;} else
      if (real[x][y]==1) {dir=0;} else
      if (real[x][y-1]==1) {dir=2;}
      else {x++;}
    }
    if (dir==2)
    {
      if (y==11) {end=1;} else
      if (real[x][y]==1) {dir=3;} else
      if (real[x-1][y]==1) {dir=1;}
      else {y++;}
    }
    if (dir==3)
    {
      if (x==0) {end=1;} else
      if (real[x-1][y]==1) {dir=0;} else
      if (real[x-1][y-1]==1) {dir=2;}
      else {x--;}
    }
    if ((x>30)||(y>20)||(y<0)||(y<0))
    {
      printf("ERROR: x or y out of range in function hidden, quitting now.\n");
      exit(1);
    }
  }
  if ((x==x_in)&&(y==y_in)&&((dir_in==dir+2)||(dir_in==dir-2)))
  {
    select_shot(x,y,dir_in,1);
    select_shot(x,y,dir,0);
    select_shot(x,y,dir,1);    
  }
  else
  {
    select_shot(x,y,dir,0);
    delay(500);
    select_shot(x_in,y_in,dir_in,1);
    select_shot(x,y,dir,1);
  }
}

void show_real()
{
  int x,y;
  
  blit_screen();
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      if (real[x][y] && !think[x][y])
        {blit(x*blocksize+blocksize*2,y*blocksize+blocksize*2,real_pic);}
    }
  }
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      if (think[x][y] && !real[x][y])
        {blit(x*blocksize+blocksize*2,y*blocksize+blocksize*2,false_pic);}
    }
  }
  XFlush(display);
  XSync(display, 0);
}

void generate_field()
{
  int x,y,crystal_num;
  
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      think[x][y]=0;
    }
  }
  while ((crystal_num>difficulty*3)||(crystal_num<(difficulty-1)*3))
  {
    crystal_num=0;
    for (x=0;x<=7;x++){
      for (y=0;y<=9;y++){
        if (abrand(0,10)==0) {real[x][y]=1;}
          else {real[x][y]=0;}
      }
    }
    for (x=0;x<=7;x++){
      for (y=0;y<=9;y++){
        if (real[x][y]==1) {crystal_num++;}
      }
    }  
  }
  for (x=0;x<=10;x++)
  {
    yline[x]=0;
  }
  for (y=0;y<=8;y++)
  {
    xline[y]=0;
  }
  won_shown=0;
}

int IsItComplete()
{
  int x,y,won=1;
  for (x=0;x<=9;x++)
  {
    if (calc_real(x,0,2).x!=calc_think(x,0,2).x) {won=0;}
    if (calc_real(x,0,2).y!=calc_think(x,0,2).y) {won=0;}
    if (calc_real(x,0,2).dir!=calc_think(x,0,2).dir) {won=0;}
  }
  for (x=0;x<=9;x++)
  {
    if (calc_real(x,11,0).x!=calc_think(x,11,0).x) {won=0;}
    if (calc_real(x,11,0).y!=calc_think(x,11,0).y) {won=0;}
    if (calc_real(x,11,0).dir!=calc_think(x,11,0).dir) {won=0;}
  }
  for (y=0;y<=11;y++)
  {
    if (calc_real(0,y,1).x!=calc_think(0,y,1).x) {won=0;}
    if (calc_real(0,y,1).y!=calc_think(0,y,1).y) {won=0;}
    if (calc_real(0,y,1).dir!=calc_think(0,y,1).dir) {won=0;}
  }
  return(won);  
}

void click()
{
  int x,y;
  
  {
//think
    if ((think[div(mouse_x,blocksize).quot-2][div(mouse_y,blocksize).quot-2]==0)
       &&(div(mouse_x,blocksize).quot>1)&&(div(mouse_y,blocksize).quot>1)
       &&(div(mouse_x,blocksize).quot<10)&&(div(mouse_y,blocksize).quot<12))
    {
      think[div(mouse_x,blocksize).quot-2][div(mouse_y,blocksize).quot-2]=1;
    } else
    if ((think[div(mouse_x,blocksize).quot-2][div(mouse_y,blocksize).quot-2]==1)
       &&(div(mouse_x,blocksize).quot>1)&&(div(mouse_y,blocksize).quot>1)
       &&(div(mouse_x,blocksize).quot<10)&&(div(mouse_y,blocksize).quot<12))
    {
      think[div(mouse_x,blocksize).quot-2][div(mouse_y,blocksize).quot-2]=0;
    }
//shot  
    if ((div(mouse_x+blocksize/2,blocksize).quot<2)
       &&(div(mouse_y+blocksize/2,blocksize).quot>1)&&(div(mouse_y+blocksize/2,blocksize).quot<13))
    {
      hidden(0,div(mouse_y+blocksize/2,blocksize).quot-2,1);
    }
    if ((div(mouse_y+blocksize/2,blocksize).quot<2)
       &&(div(mouse_x+blocksize/2,blocksize).quot>1)&&(div(mouse_x+blocksize/2,blocksize).quot<11))
    {
      hidden(div(mouse_x+blocksize/2,blocksize).quot-2,0,2);
    }
    if ((div(mouse_y+blocksize/2,blocksize).quot>12)&&(div(mouse_y+blocksize/2,blocksize).quot<15)
       &&(div(mouse_x+blocksize/2,blocksize).quot>1)&&(div(mouse_x+blocksize/2,blocksize).quot<11))
    {
      hidden(div(mouse_x+blocksize/2,blocksize).quot-2,11,0);
    }
    // "new" button
    if ((mouse_x<44)&&(mouse_y>206))
    {
      generate_field();
      blit_screen();
    }
    // "quit" button
    if ((mouse_x>100)&&(mouse_y>206))
    {
      printf("Quit pressed, quitting...\n");
      exit(1);
    } 
  }
  blit_screen();
  if ((mouse_x>50)&&(mouse_x<100)&&(mouse_y>206))
  {
    // "give up" button
    show_real();
  }
}

void get_click()
{
  XEvent event;
  
  while (1) {
    while (XPending(display)) {
	XNextEvent(display, &event);
	if (event.type == Expose) {
            XFillRectangle(display, window, blackgc, 0, 0, xscreen, yscreen);
	    blit_screen();
	} else if (event.type == ButtonPress) {
    	    click();
	} else if (event.type == MotionNotify) {
	    mouse_x = event.xbutton.x;
	    mouse_y = event.xbutton.y;
	}
    }
    if ((IsItComplete())&&(!won_shown)) {
      won_shown=1;
      blit(41,88,won_pic);
    }
    XFlush(display);
    XSync(display, 0);
    delay(60);
  }
}

void LoadImage(char ** xpm, Image * image)
{
    XpmAttributes attrib; 

    XpmCreatePixmapFromData(display, window, xpm, &image->pix, NULL, NULL);
}


void load_images()
{
    LoadImage(box_xpm, &box_pic);
    LoadImage(edge1_xpm, &edge1_pic);
    LoadImage(edge2_xpm, &edge2_pic);
    LoadImage(edge3_xpm, &edge3_pic);
    LoadImage(edge1red_xpm, &edge1rred_pic);
    LoadImage(edge2red_xpm, &edge2rred_pic);
    LoadImage(edge3red_xpm, &edge3rred_pic);
    LoadImage(think_xpm, &think_pic);
    LoadImage(real_xpm, &real_pic);
    LoadImage(false_xpm, &false_pic);
    LoadImage(new_xpm, &new_pic);
    LoadImage(quit_xpm, &quit_pic);
    LoadImage(giveup_xpm, &giveup_pic);
    LoadImage(won_xpm, &won_pic);
    
    box_pic.width = box_pic.height = blocksize;
    edge1_pic.width = edge1_pic.height = blocksize;
    edge2_pic.width = edge2_pic.height = blocksize;
    edge3_pic.width = edge3_pic.height = blocksize;
    edge1rred_pic.width = edge1rred_pic.height = blocksize;
    edge2rred_pic.width = edge2rred_pic.height = blocksize;
    edge3rred_pic.width = edge3rred_pic.height = blocksize;
    think_pic.width = think_pic.height = blocksize;
    real_pic.width = real_pic.height = blocksize;
    false_pic.width = false_pic.height = blocksize;

    new_pic.width = 51; new_pic.height = 23;
    quit_pic.width = 50; quit_pic.height = 25;
    giveup_pic.width = 46; giveup_pic.height = 30;
    won_pic.width = 84; won_pic.height = 16;
}

int main(int argc, char *argv[])
{
  printf("\nBlack-Box version %s, Copyright (C) 2000 Karl Bartel\n",VERSION);
  printf("Black-Box comes with ABSOLUTELY NO WARRANTY; for details see COPYING'.\n");
  printf("This is free software, and you are welcome to redistribute it\n");
  printf("under certain conditions.\n");
  level_num=((unsigned)time(NULL)%100000);
  init_x11();
  srand(time(NULL));
  load_images();
  generate_field();
  XFillRectangle(display, window, blackgc, 0, 0, xscreen, yscreen);
  XFlush(display);
  XSync(display, 0);
  blit_screen();
  get_click();
  exit(0);
}
