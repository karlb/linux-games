#ifndef BOARD_H
#define BOARD_H

#include <qwidget.h>
#include <qbitmap.h>
#include <qtimer.h>
#include <qpoint.h>
#include <qlist.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>
#include <qtimer.h>
#include <qpixmap.h>

#include "black-box.h"

typedef struct {
       int x;
       int y;
       int dir;
} output;


class Board : public QWidget
{
	Q_OBJECT

public:
	Board(QWidget* parent=0, const char* name=0, WFlags f=0 );
	void startLevel();
	void setPix(int x, int y, int r, int g ,int b);
	void blit(int x, int y, QPixmap *pix);
	void load(char *filename, Image *image);

	int difficulty;
	void generate_field();
	void show_real();

protected:
	void mousePressEvent ( QMouseEvent * ); 
	void paintEvent ( QPaintEvent * );

private:
	QPixmap blockPic[5], movedPic[5], emptyPic, selectPic, wonPic, possiblePic, faultPic, middlePic;
	QPixmap *buffer;
	int map[5][5], selected[5][5];
	int blockWidth, blockHeight, selectCount, selectedType;
	float interval;
	bool fault;
	QTimer *newBlockTimer, *selectTimer, *middleTimer, *faultTimer;

       static const int trihigh=1;   //settings

//       XEvent event;
       Image box_pic,edge1_pic,edge2_pic,edge3_pic,think_pic;
       Image real_pic, false_pic;
       Image edge1red_pic,edge2red_pic,edge3red_pic;
       Image edge1rred_pic,edge2rred_pic,edge3rred_pic;
       int mouse_x, mouse_y, level_num, won_shown;
       static const int blocksize = 19;
       static const int xscreen = 220;
       static const int yscreen = 265;
       char text[80];
       char xline[11];
       char yline[11];
       char think[11][11];
       char real[11][11];
       bool given_up;
	
	void delay(unsigned long ms);
	void setpix( int X, int Y, int red, int green, int blue);
	void update();
	void blit(int Xpos,int Ypos,Image image);
	int abrand(int a,int b);
	void xshot(int y,int right,int erase);
	void xshot2(int y,int right,int erase);
	void yshot(int y,int right,int erase);
	void yshot2(int y,int right,int erase);
	void select_shot(int x,int y,int dir,int erase);
	output calc_real(int x,int y,int dir);
	output calc_think(int x,int y,int dir);
	void blit_screen();
	void hidden(int x,int y,int dir);
	int IsItComplete();
	void click();
	void LoadImage(char *filename , Image *image);
	void load_images();
	void black_box_main();
	
};

#endif
