#include <qpainter.h>
#include <qimage.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qpushbutton.h>
#include <qapplication.h>
#include <qmessagebox.h>

#include "app_window.h"
#include "board.h"
#include "levels.h"

AppWindow::AppWindow( QWidget* parent, const char* name, WFlags f )
	: QMainWindow( parent, name, f )
{
	setCaption("zBlack-Box");
	srand(time(NULL));

	board = new Board(this);
	board->setGeometry(0, 20, 240, 265);

	QMenuBar *mb=menuBar();

    appMenu = new QPopupMenu;
	appMenu->insertItem( "&About", ABOUT);
	appMenu->insertItem( "&Rules", RULES);
	appMenu->insertSeparator();
	appMenu->insertItem( "&Exit", EXIT);
	mb->insertItem("&zBlack-Box", appMenu);
	connect( appMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
    levelMenu = new QPopupMenu;
	levelMenu->insertItem( "&Give Up", GIVE_UP);
	levelMenu->insertSeparator();
	levelMenu->insertItem( "&Very easy game", LEVELNUM+0);
	levelMenu->insertItem( "&Easy game", LEVELNUM+1);
	levelMenu->insertItem( "&Normal game", LEVELNUM+2);
	levelMenu->insertItem( "&Hard game", LEVELNUM+3);
	mb->insertItem("&New Game", levelMenu);
	connect( levelMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
}

void AppWindow::paintEvent ( QPaintEvent * )
{
	QPixmap tpix(width(),height());
	tpix.fill(QColor(199,190,166));
	
	QPainter p(this);
	p.drawPixmap(0,0,tpix);
	
}


void AppWindow::menuSelected(int id)
{
	switch(id) {
		case EXIT:
			close();
		break;
		case ABOUT:
			QMessageBox *abox;
			abox = new QMessageBox(this, "About");
			abox->setText("<center><B>zBlack-Box</B><BR>www.linux-games.com<BR><BR>(c) 2002 by Karl Bartel<BR>This is free Software (GPL)</center>");
			abox->show();
		break;
		case RULES:
			QMessageBox *rbox;
			rbox = new QMessageBox(this, "Rules");
			rbox->setText("<center><B>zBlack-Box Rules</B></center><BR><B>Goal: </B>There's a number of crystals hidden in the box. Find them all!<BR><B>Shooting: </B>Tap on the little triangles at the side to shoot into the box. The crytals in the box reflect your shots, so you can make assumptions where the crystals are by watching where the shot leaves the box.<BR><b>Red/Green Indicators: </b>Red triangles indicate that your current assumption doesn't work for that triangle. Try to turn all triangles green!");
			rbox->setMaximumWidth(210);
			rbox->show();
		break;
		case LEVELNUM:
		case LEVELNUM+1:
		case LEVELNUM+2:
		case LEVELNUM+3:
			board->difficulty = id - LEVELNUM + 2;
			board->generate_field();
			board->startLevel();
		break;
		case GIVE_UP:
			board->show_real();
		default:
		break;
	}

}
