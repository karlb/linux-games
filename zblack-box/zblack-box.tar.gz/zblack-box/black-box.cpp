/*  Black-box: guess where the crystals are !                                           
    Copyright (C) 2000 Karl Bartel                                              
                                                                                
    This program is free software; you can redistribute it and/or modify        
    it under the terms of the GNU General Public License as published by        
    the Free Software Foundation; either version 2 of the License, or           
    (at your option) any later version.                                         
                                                                                
    This program is distributed in the hope that it will be useful,             
    but WITHOUT ANY WARRANTY; without even the implied warranty of              
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               
    GNU General Public License for more details.                                
                                                                                
    You should have received a copy of the GNU General Public License           
    along with this program; if not, write to the Free Software                 
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   
                                                                                
    Karl Bartel                                                                 
    Cecilienstr. 14                                                             
    12307 Berlin                                                                
    GERMANY                                                                     
    karlb@gmx.net                                                               
*/                                                                              


#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <signal.h>

#include "black-box.h"
#include "board.h"
#include "app_window.h"
#include <qmessagebox.h>
#include <qpainter.h>

void Board::delay(unsigned long ms)
{
    usleep(ms*1000);
}

void Board::setpix( int X, int Y, int red, int green, int blue)  //sets one Pixel to the screen 
{
    setPix(X, Y, red, green, blue);
}

void Board::update()
{
    QPainter final(this);
    final.drawPixmap(0, 0, *buffer);
}

void Board::blit(int Xpos,int Ypos,Image image) 
{
    blit(Xpos, Ypos, image.pix);
}

int Board::abrand(int a,int b)  //random number between a and b (inclusive)
{
  return(a+(rand() % (b-a+1)));
}


void Board::xshot(int y,int right,int erase) //x right
{
  int move;
  for (move=blocksize/2;move<blocksize*3/2;move++)
  {
    if (erase)
    {
      setpix(move+right*blocksize*10,y,0,0,0);
      setpix(move+right*blocksize*10,y+1,0,0,0);
      setpix(move+right*blocksize*10,y-1,0,0,0);
    }
    else
    {
      setpix(move+right*blocksize*10,y,255,0,0);
      setpix(move+right*blocksize*10,y+1,255,0,0);
      setpix(move+right*blocksize*10,y-1,255,0,0);
    }
    if (move % 2==0) delay(1);
    update();
  }
}

void Board::xshot2(int y,int right,int erase) //x left
{
  int move;
  for (move=blocksize*3/2;move>blocksize/2;move--)
  {
    if (erase)
    {
      setpix(move+right*blocksize*10,y,0,0,0);
      setpix(move+right*blocksize*10,y+1,0,0,0);
      setpix(move+right*blocksize*10,y-1,0,0,0);
    }
    else
    {
      setpix(move+right*blocksize*10,y,255,0,0);
      setpix(move+right*blocksize*10,y+1,255,0,0);
      setpix(move+right*blocksize*10,y-1,255,0,0);
    }
    if (move % 2==0) delay(1);
    update();
  }
}

void Board::yshot(int x,int down,int erase) // y down
{
  int move;
  for (move=blocksize/2;move<blocksize*3/2;move++)
  {
    if (erase)
    {
      setpix(x,move+down*blocksize*12,0,0,0);
      setpix(x+1,move+down*blocksize*12,0,0,0);
      setpix(x-1,move+down*blocksize*12,0,0,0);
    }
    else 
    {
      setpix(x,move+down*blocksize*12,255,0,0);
      setpix(x+1,move+down*blocksize*12,255,0,0);
      setpix(x-1,move+down*blocksize*12,255,0,0);
    }
    if (move % 2==0) delay(1);
    update();
  }
}

void Board::yshot2(int x,int down,int erase)  //y up
{
  int move;
  for (move=blocksize*3/2;move>blocksize/2;move--)
  {
    if (erase)
    {
      setpix(x,move+down*blocksize*12,0,0,0);
      setpix(x+1,move+down*blocksize*12,0,0,0);
      setpix(x-1,move+down*blocksize*12,0,0,0);
    }
    else 
    {
      setpix(x,move+down*blocksize*12,255,0,0);
      setpix(x+1,move+down*blocksize*12,255,0,0);
      setpix(x-1,move+down*blocksize*12,255,0,0);
    }
    if (move % 2==0) delay(1);
    update();
  }
}

void Board::select_shot(int x,int y,int dir,int erase)
{
  if ((dir==1)||(dir==3))
  {
    if (dir==1)
      xshot((y+2)*blocksize,div(x,9).quot,erase);
    if (dir==3)
      xshot2((y+2)*blocksize,div(x,9).quot,erase);
  }
  else
  {
    if (dir==0)
      yshot2((x+2)*blocksize,div(y,11).quot,erase);
    if (dir==2)
      yshot((x+2)*blocksize,div(y,11).quot,erase);
  }
}

output Board::calc_real(int x,int y,int dir)
{
  int end=0;
  output out;
  
  while (!end)
  {
    if (dir==0) 
    {
      if (y==0) {end=1;} else
      if (real[x-1][y-1]==1) {dir=1;} else
      if (real[x][y-1]==1) {dir=3;}
      else {y--;}
    }
    if (dir==1)
    {
      if (x==9) {end=1;} else
      if (real[x][y]==1) {dir=0;} else
      if (real[x][y-1]==1) {dir=2;}
      else {x++;}
    }
    if (dir==2)
    {
      if (y==11) {end=1;} else
      if (real[x][y]==1) {dir=3;} else
      if (real[x-1][y]==1) {dir=1;}
      else {y++;}
    }
    if (dir==3)
    {
      if (x==0) {end=1;} else
      if (real[x-1][y]==1) {dir=0;} else
      if (real[x-1][y-1]==1) {dir=2;}
      else {x--;}
    }
    if ((x>30)||(y>20)||(y<0)||(y<0))
    {
      printf("ERROR: x or y out of range in function hidden, quitting now.\n");
      exit(1);
    }
  }
  out.x=x;
  out.y=y;
  out.dir=dir;
  

  return(out);
}

output Board::calc_think(int x,int y,int dir)
{
  int end=0;
  output out;
  
  while (!end)
  {
    if (dir==0) 
    {
      if (y==0) {end=1;} else
      if (think[x-1][y-1]==1) {dir=1;} else
      if (think[x][y-1]==1) {dir=3;}
      else {y--;}
    }
    if (dir==1)
    {
      if (x==9) {end=1;} else
      if (think[x][y]==1) {dir=0;} else
      if (think[x][y-1]==1) {dir=2;}
      else {x++;}
    }
    if (dir==2)
    {
      if (y==11) {end=1;} else
      if (think[x][y]==1) {dir=3;} else
      if (think[x-1][y]==1) {dir=1;}
      else {y++;}
    }
    if (dir==3)
    {
      if (x==0) {end=1;} else
      if (think[x-1][y]==1) {dir=0;} else
      if (think[x-1][y-1]==1) {dir=2;}
      else {x--;}
    }
    if ((x>30)||(y>20)||(y<0)||(y<0))
    {
      printf("ERROR: x or y out of range in function hidden, quitting now.\n");
      exit(1);
    }
  }
  out.x=x;
  out.y=y;
  out.dir=dir;
  
  return(out);
}

void Board::blit_screen()
{
  int x,y;
  
  won_shown=0;
  /*blit(0,211,new_pic);
  blit(55,208,giveup_pic);
  blit(105,210,quit_pic);*/
  if (trihigh)
  {
    edge1red_pic=edge1rred_pic;
    edge2red_pic=edge2rred_pic;
    edge3red_pic=edge3rred_pic;
  }else
  {
    edge1red_pic=edge1_pic;
    edge2red_pic=edge2_pic;
    edge3red_pic=edge3_pic;
  }
  
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      blit(x*blocksize+blocksize*3/2,y*blocksize+blocksize*3/2,box_pic);
    }
  }
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      if (think[x][y])
        {blit(x*blocksize+blocksize*2,y*blocksize+blocksize*2,think_pic);}
    }
  }
  for (x=0;x<=8;x++){
    if ((calc_real(x,0,2).x==calc_think(x,0,2).x)
       &&(calc_real(x,0,2).y==calc_think(x,0,2).y)
       &&(calc_real(x,0,2).dir==calc_think(x,0,2).dir))
    {blit(x*blocksize+blocksize*3/2,0,edge1_pic);}
    else {blit(x*blocksize+blocksize*3/2,0,edge1red_pic);}
  }
  for (y=0;y<=10;y++){
    if ((calc_real(0,y,1).x==calc_think(0,y,1).x)
       &&(calc_real(0,y,1).y==calc_think(0,y,1).y)
       &&(calc_real(0,y,1).dir==calc_think(0,y,1).dir))
    {blit(0,y*blocksize+blocksize*3/2,edge2_pic);}
    else {blit(0,y*blocksize+blocksize*3/2,edge2red_pic);}
  }  
  for (x=0;x<=8;x++){
    if ((calc_real(x,11,0).x==calc_think(x,11,0).x)
       &&(calc_real(x,11,0).y==calc_think(x,11,0).y)
       &&(calc_real(x,11,0).dir==calc_think(x,11,0).dir))
    {blit(x*blocksize+blocksize*3/2,blocksize*14-15,edge3_pic);}
    else {blit(x*blocksize+blocksize*3/2,blocksize*14-15,edge3red_pic);}
  }
  
  if (given_up)
	show_real();
}

void Board::show_real()
{
  int x,y;
  
  //blit_screen();
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      if (real[x][y] && !think[x][y])
        {blit(x*blocksize+blocksize*2,y*blocksize+blocksize*2,real_pic);}
    }
  }
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      if (think[x][y] && !real[x][y])
        {blit(x*blocksize+blocksize*2,y*blocksize+blocksize*2,false_pic);}
    }
  }
  update();
  given_up = true;
}


void Board::hidden(int x,int y,int dir)  //0=up 1=right 2=down 3=left
{
  int end=0,x_in,y_in,dir_in;

  x_in=x;
  y_in=y;  
  dir_in=dir;
  
  select_shot(x,y,dir,0);
  while (!end)
  {
    if (dir==0) 
    {
      if (y==0) {end=1;} else
      if (real[x-1][y-1]==1) {dir=1;} else
      if (real[x][y-1]==1) {dir=3;}
      else {y--;}
    }
    if (dir==1)
    {
      if (x==9) {end=1;} else
      if (real[x][y]==1) {dir=0;} else
      if (real[x][y-1]==1) {dir=2;}
      else {x++;}
    }
    if (dir==2)
    {
      if (y==11) {end=1;} else
      if (real[x][y]==1) {dir=3;} else
      if (real[x-1][y]==1) {dir=1;}
      else {y++;}
    }
    if (dir==3)
    {
      if (x==0) {end=1;} else
      if (real[x-1][y]==1) {dir=0;} else
      if (real[x-1][y-1]==1) {dir=2;}
      else {x--;}
    }
    if ((x>30)||(y>20)||(y<0)||(y<0))
    {
      printf("ERROR: x or y out of range in function hidden, quitting now.\n");
      exit(1);
    }
  }
  if ((x==x_in)&&(y==y_in)&&((dir_in==dir+2)||(dir_in==dir-2)))
  {
    select_shot(x,y,dir_in,1);
    select_shot(x,y,dir,0);
    select_shot(x,y,dir,1);    
  }
  else
  {
    select_shot(x,y,dir,0);
    delay(500);
    select_shot(x_in,y_in,dir_in,1);
    select_shot(x,y,dir,1);
  }
}

void Board::generate_field()
{
  int x,y,crystal_num;
  
  for (x=0;x<=8;x++){
    for (y=0;y<=10;y++){
      think[x][y]=0;
    }
  }
  while ((crystal_num>difficulty*3)||(crystal_num<(difficulty-1)*3))
  {
    crystal_num=0;
    for (x=0;x<=7;x++){
      for (y=0;y<=9;y++){
        if (abrand(0,10)==0) {real[x][y]=1;}
          else {real[x][y]=0;}
      }
    }
    for (x=0;x<=7;x++){
      for (y=0;y<=9;y++){
        if (real[x][y]==1) {crystal_num++;}
      }
    }  
  }
  for (x=0;x<=10;x++)
  {
    yline[x]=0;
  }
  for (y=0;y<=8;y++)
  {
    xline[y]=0;
  }
  won_shown=0;
}

int Board::IsItComplete()
{
  int x,y,won=1;
  for (x=0;x<=9;x++)
  {
    if (calc_real(x,0,2).x!=calc_think(x,0,2).x) {won=0;}
    if (calc_real(x,0,2).y!=calc_think(x,0,2).y) {won=0;}
    if (calc_real(x,0,2).dir!=calc_think(x,0,2).dir) {won=0;}
  }
  for (x=0;x<=9;x++)
  {
    if (calc_real(x,11,0).x!=calc_think(x,11,0).x) {won=0;}
    if (calc_real(x,11,0).y!=calc_think(x,11,0).y) {won=0;}
    if (calc_real(x,11,0).dir!=calc_think(x,11,0).dir) {won=0;}
  }
  for (y=0;y<=11;y++)
  {
    if (calc_real(0,y,1).x!=calc_think(0,y,1).x) {won=0;}
    if (calc_real(0,y,1).y!=calc_think(0,y,1).y) {won=0;}
    if (calc_real(0,y,1).dir!=calc_think(0,y,1).dir) {won=0;}
  }
  return(won);  
}

void Board::click()
{
  
//think
    if ((think[div(mouse_x,blocksize).quot-2][div(mouse_y,blocksize).quot-2]==0)
       &&(div(mouse_x,blocksize).quot>1)&&(div(mouse_y,blocksize).quot>1)
       &&(div(mouse_x,blocksize).quot<10)&&(div(mouse_y,blocksize).quot<12))
    {
      think[div(mouse_x,blocksize).quot-2][div(mouse_y,blocksize).quot-2]=1;
    } else
    if ((think[div(mouse_x,blocksize).quot-2][div(mouse_y,blocksize).quot-2]==1)
       &&(div(mouse_x,blocksize).quot>1)&&(div(mouse_y,blocksize).quot>1)
       &&(div(mouse_x,blocksize).quot<10)&&(div(mouse_y,blocksize).quot<12))
    {
      think[div(mouse_x,blocksize).quot-2][div(mouse_y,blocksize).quot-2]=0;
    }
//shot  
    if ((div(mouse_x+blocksize/2,blocksize).quot<2)
       &&(div(mouse_y+blocksize/2,blocksize).quot>1)&&(div(mouse_y+blocksize/2,blocksize).quot<13))
    {
      hidden(0,div(mouse_y+blocksize/2,blocksize).quot-2,1);
    }
    if ((div(mouse_y+blocksize/2,blocksize).quot<2)
       &&(div(mouse_x+blocksize/2,blocksize).quot>1)&&(div(mouse_x+blocksize/2,blocksize).quot<11))
    {
      hidden(div(mouse_x+blocksize/2,blocksize).quot-2,0,2);
    }
    if ((div(mouse_y+blocksize/2,blocksize).quot>12)&&(div(mouse_y+blocksize/2,blocksize).quot<15)
       &&(div(mouse_x+blocksize/2,blocksize).quot>1)&&(div(mouse_x+blocksize/2,blocksize).quot<11))
    {
      hidden(div(mouse_x+blocksize/2,blocksize).quot-2,11,0);
    }
    blit_screen();
    if (IsItComplete() && !given_up) {
	    QMessageBox *abox;
	    abox = new QMessageBox(this, "Won");
	    abox->setText("<center><b>Congratulations</b><BR><BR>You have solved this level!</center>");
	    abox->show();
    }
    update();
}


void Board::LoadImage(char *filename , Image *image)
{
    load(filename, image);
}


void Board::load_images()
{
    LoadImage("box", &box_pic);
    LoadImage("edge1", &edge1_pic);
    LoadImage("edge2", &edge2_pic);
    LoadImage("edge3", &edge3_pic);
    LoadImage("edge1red", &edge1rred_pic);
    LoadImage("edge2red", &edge2rred_pic);
    LoadImage("edge3red", &edge3rred_pic);
    LoadImage("think", &think_pic);
    LoadImage("real", &real_pic);
    LoadImage("false", &false_pic);
    
    box_pic.width = box_pic.height = blocksize;
    edge1_pic.width = edge1_pic.height = blocksize;
    edge2_pic.width = edge2_pic.height = blocksize;
    edge3_pic.width = edge3_pic.height = blocksize;
    edge1rred_pic.width = edge1rred_pic.height = blocksize;
    edge2rred_pic.width = edge2rred_pic.height = blocksize;
    edge3rred_pic.width = edge3rred_pic.height = blocksize;
    think_pic.width = think_pic.height = blocksize;
    real_pic.width = real_pic.height = blocksize;
    false_pic.width = false_pic.height = blocksize;

}

void Board::black_box_main()
{
  level_num=((unsigned)time(NULL)%100000);
  srand(time(NULL));
  load_images();
  given_up = false;
  generate_field();
  blit_screen();
}
