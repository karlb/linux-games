#include "board.h"
#include <qpainter.h>
#include <qmessagebox.h> 
#include <qpe/resource.h>
#include "black-box.h"

const char GFX_PATH[] = "data/gfx";
const char xblocks = 5, yblocks = 5, blockTypes = 4;
const int  selectTime = 2000, faultTime = 3000;

//#include "black-box.cpp"

Board::Board(QWidget* parent, const char* name, WFlags f ): QWidget(parent,name,f)
{
	buffer = new QPixmap(240, 265);

	difficulty = 4;
	black_box_main();
	startLevel();
}

void Board::setPix(int x, int y, int r, int g ,int b)
{
	QPainter p(buffer);
	
	p.setPen(QColor(r,g,b));
	p.drawPoint(x,y);
}

void Board::blit(int x, int y, QPixmap *pix)
{
	QPainter p(buffer);

	p.drawPixmap(x, y, *pix);
}

void Board::load(char *file, Image *image)
{
	const char appName[] = "zblack-box";
	const char GFX_PATH[] = "ipk/opt/QtPalmtop/pics";

	if (getenv("XAUTHORITY") == NULL) {
		char filename[80];
		sprintf(filename, "%s/%s", appName, file);

		QPixmap *ret;
		ret = new QPixmap;
		*ret = Resource::loadPixmap(filename);
		image->pix = ret;
	} else {
		char filename[80];
		QPixmap *ret;
		ret = new QPixmap;
	
		sprintf(filename, "%s/%s/%s.png", GFX_PATH, appName, file);
		if (!ret->load(filename))
			printf("Couldn't load %s\n",filename);
			
		image->pix = ret;
	}

}


void Board::startLevel()
{
	selectedType = -1;
	given_up = false;
	paintEvent(NULL);
}

void Board::paintEvent ( QPaintEvent *pe) 
{
	QPixmap tpix(width(),height());
	tpix.fill(QColor(0,0,0));
	QPainter p(buffer);
	p.drawPixmap(0,0,tpix);
	
	blit_screen();
	update();
}


void Board::mousePressEvent ( QMouseEvent *e )
{

	mouse_x = e->x();
	mouse_y = e->y();
	click();
}

