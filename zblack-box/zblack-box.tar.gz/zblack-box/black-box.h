#ifndef BB_H
#define BB_H

#include <qpixmap.h>

typedef struct {
	QPixmap *pix;
	int width;
	int height;
} Image;


#endif
