#ifndef ZNUMBERS_WINDOW_H
#define ZNUMBERS_WINDOW_H
#include <qmainwindow.h>
#include "board.h"

class AppWindow : public QMainWindow
{
	Q_OBJECT
public:
	AppWindow( QWidget* parent = 0, const char* name = 0, WFlags f = WType_TopLevel );
	Board *board;
	
protected:
	void paintEvent ( QPaintEvent * );

private slots:
	void menuSelected(int);

private:

	enum MenuItems
	{
		EXIT,
		ABOUT,
		RULES,
		GIVE_UP,
		
		LEVELNUM
	};

	QPopupMenu* appMenu;
	QPopupMenu* levelMenu;

};

extern AppWindow *mywindow;

#endif
