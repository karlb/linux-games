#include <qpe/qpeapplication.h>
#include "app_window.h"

AppWindow *mywindow;

int main( int argc, char** argv )
{
	QPEApplication app( argc, argv );

	mywindow = new AppWindow(0,"zNumbers", 0);

	app.showMainWidget( mywindow ); 

	return app.exec();
}

