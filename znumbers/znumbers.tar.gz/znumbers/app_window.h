#ifndef ZNUMBERS_WINDOW_H
#define ZNUMBERS_WINDOW_H
#include <qmainwindow.h>
#include "board.h"

class AppWindow : public QMainWindow
{
	Q_OBJECT
public:
	AppWindow( QWidget* parent = 0, const char* name = 0, WFlags f = WType_TopLevel );
	
protected:
	void paintEvent ( QPaintEvent * );

private slots:
	void menuSelected(int);

private:

	enum MenuItems
	{
		RESTART_LEVEL,
		NEW_RAND_LEVEL,
		EXIT,
		ABOUT,
		RULES,
		
		LEVELNUM
	};

	QPopupMenu* appMenu;
	QPopupMenu* levelMenu;

	Board *board;
};

#endif
