#include "board.h"
#include <qpainter.h>
#include <qmessagebox.h> 

const char GFX_PATH[] = "data/gfx";

Board::Board(QWidget* parent, const char* name, WFlags f ): QWidget(parent,name,f)
{
	char filename[80];
	for (int i=0; i<4; i++) {
		sprintf(filename, "p%d", i+1);
		blockPic[i] = loadPixmap(filename);
	}
	for (int i=0; i<4; i++) {
		sprintf(filename, "p%d_moved", i+1);
		movedPic[i] = loadPixmap(filename);
	}
	
	possiblePic = loadPixmap("possible");
	emptyPic = loadPixmap("ground");
	selectPic = loadPixmap("select");
	wonPic = loadPixmap("won");

	blockWidth  = blockPic[0].width();
	blockHeight = blockPic[0].height();

	randLevel();
	saveLevel();
	startLevel();
}

void Board::loadLevel()
{
	for (int y = 0; y < 6; y++) {
	    for (int x = 0; x < 6; x++) {
	        map[y][x] = oldmap[x][y];
	    }
        }
	startLevel();
}

void Board::saveLevel()
{
	for (int y = 0; y < 6; y++) {
	    for (int x = 0; x < 6; x++) {
	        oldmap[y][x] = map[x][y];
	    }
        }
}

bool Board::trymove(int x, int y, int newblock) {
    
        if ( (x < 0) || (x >= 6) ) return 1;
        if ( (y < 0) || (y >= 6) ) return 1;
      
        if (map[y][x] == 0) {
    		map[y][x] = newblock;
    		return false;
        }
	return true;
}

void Board::randLevel()
{
	int newblock;

	for (int y = 0; y < 6; y++) {
	    for (int x = 0; x < 6; x++) {
	        map[y][x]=0;
	    }
        }
	for (int y = 0; y < 6; y++) {
	    for (int x = 0; x < 6; x++) {
    	      	do {
		    newblock = (rand() % (5));
		} while ( (newblock != 0) && (map[y][x] == 0) 
			&& trymove(x-newblock,y,newblock) && trymove(x,y-newblock,newblock) 
			&& trymove(x,y+newblock,newblock) && trymove(x+newblock,y,newblock)
			&& trymove(x-newblock,y-newblock,newblock) && trymove(x+newblock,y-newblock,newblock) 
			&& trymove(x+newblock,y+newblock,newblock) && trymove(x+newblock,y-newblock,newblock) );
	    }
	}
}

void Board::setLevel(int x, int y, char val)
{
	map[x][y] = val;
}

void Board::startLevel()
{
	selectX = -1;
	selectY = -1;
	paintEvent(NULL);
}

void Board::paintEvent ( QPaintEvent *pe) 
{

	QPixmap tpix(width(),height());
	tpix.fill(QColor(1,255,16));
	
	QPainter p(this);
	p.moveTo(0,0);

	for (int x=0; x<6; x++) {
		for (int y=0; y<6; y++) {
			if (map[x][y] > 0) 
				p.drawPixmap(blockWidth*x, blockHeight*y, blockPic[map[x][y]-1]);
			else if (map[x][y] < 0)
				p.drawPixmap(blockWidth*x, blockHeight*y, movedPic[-map[x][y]-1]);
			else {
				if (isAllowed(x,y))
					p.drawPixmap(blockWidth*x, blockHeight*y, possiblePic);
				else
					p.drawPixmap(blockWidth*x, blockHeight*y, emptyPic);
			}
		}
	}
	if (selectX >= 0)
		p.drawPixmap(blockWidth*selectX, blockHeight*selectY, selectPic);

	if (finished())
		p.drawPixmap(width()/2 - wonPic.width()/2, height()/2 - wonPic.height()/2, wonPic);
	
}

bool Board::isAllowed(int x, int y)
{
	int xdiff = abs(selectX-x);
	int ydiff = abs(selectY-y);

	if ( xdiff == ydiff) {
		if (xdiff == map[selectX][selectY])
			return true;
	} else {
		if ((xdiff == 0) && (ydiff == map[selectX][selectY]))
			return true;
		if ((ydiff == 0) && (xdiff == map[selectX][selectY]))
			return true;
	}
				
	return false;
}

bool Board::finished()
{
	for (int x=0; x<6; x++)
		for (int y=0; y<6; y++)
			if (map[x][y] > 0)
				return false;
	
	return true;
}

void Board::mousePressEvent ( QMouseEvent *e )
{
	if (finished())
		return;

	int x = e->x() / blockWidth;
	int y = e->y() / blockHeight;

	QPainter p(this);

	if ((selectX >= 0) && (map[x][y] == 0)) {
		if (isAllowed(x,y)) {
			map[x][y] = -map[selectX][selectY];
			map[selectX][selectY] = 0;
			selectX = -1;
			selectY = -1;
			paintEvent(NULL);
		}
	} else {
		if (map[x][y] <= 0)
			return;

		selectX = x;
		selectY = y;
		paintEvent(NULL);
	}
}

QPixmap Board::loadPixmap(char *file)
{
	const char appName[] = "znumbers";
	const char GFX_PATH[] = "ipk/opt/QtPalmtop/pics";

	if (getenv("XAUTHORITY") == NULL) {
		char filename[80];
		sprintf(filename, "%s/%s", appName, file);

		return Resource::loadPixmap(filename);
	} else {
		char filename[80];
		QPixmap *ret;
		ret = new QPixmap;
	
		sprintf(filename, "%s/%s/%s.png", GFX_PATH, appName, file);
		if (!ret->load(filename))
			printf("Couldn't load %s\n",filename);
			
		return *ret;
	}
}
