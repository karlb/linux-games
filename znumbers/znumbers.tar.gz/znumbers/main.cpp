#include <qpe/qpeapplication.h>
#include "app_window.h"

int main( int argc, char** argv )
{
	QPEApplication app( argc, argv );

	AppWindow window(0,"appWindow", 0);

	app.showMainWidget( &window ); 

	return app.exec();
}

