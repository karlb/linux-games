#include <qpainter.h>
#include <qimage.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qpushbutton.h>
#include <qapplication.h>
#include <qmessagebox.h>

#include "app_window.h"
#include "board.h"
#include "levels.h"

AppWindow::AppWindow( QWidget* parent, const char* name, WFlags f )
	: QMainWindow( parent, name, f )
{
	setCaption("zNumbers");
	srand(time(NULL));

	board = new Board(this);
	board->setGeometry(6, 40, 228, 228);

	QMenuBar *mb=menuBar();

    appMenu = new QPopupMenu;
	appMenu->insertItem( "&About", ABOUT);
	appMenu->insertItem( "&Rules", RULES);
	appMenu->insertSeparator();
	appMenu->insertItem( "&Exit", EXIT);
	mb->insertItem("&zNumbers", appMenu);
	connect( appMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
    levelMenu = new QPopupMenu;
	levelMenu->insertItem( "&Restart Level", RESTART_LEVEL);
	levelMenu->insertItem( "&New random Level", NEW_RAND_LEVEL);
	levelMenu->insertSeparator();
	levelMenu->insertItem( "&Level 1", LEVELNUM+0);
	levelMenu->insertItem( "&Level 2", LEVELNUM+1);
	levelMenu->insertItem( "&Level 3", LEVELNUM+2);
	levelMenu->insertItem( "&Level 4", LEVELNUM+3);
	levelMenu->insertItem( "&Level 5", LEVELNUM+4);
	levelMenu->insertItem( "&Level 6", LEVELNUM+5);
	levelMenu->insertItem( "&Level 7", LEVELNUM+6);
	levelMenu->insertItem( "&Level 8", LEVELNUM+7);
	levelMenu->insertItem( "&Level 9", LEVELNUM+8);
	levelMenu->insertItem( "&Level 10", LEVELNUM+9);
	mb->insertItem("&Level", levelMenu);
	connect( levelMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
}

void AppWindow::paintEvent ( QPaintEvent * )
{
	QPixmap tpix(width(),height());
	tpix.fill(QColor(199,190,166));
	
	QPainter p(this);
	p.drawPixmap(0,0,tpix);
	
}


void AppWindow::menuSelected(int id)
{
	int levelNum = -1;

	switch(id) {
		case EXIT:
			close();
		break;
		case ABOUT:
			QMessageBox *abox;
			abox = new QMessageBox(this, "About");
			abox->setText("<center><B>zNumbers</B><BR>www.linux-games.com<BR><BR>(c) 2002 by Karl Bartel<BR>This is free Software (GPL)</center>");
			abox->show();
		break;
		case RULES:
			QMessageBox *rbox;
			rbox = new QMessageBox(this, "Rules");
			rbox->setText("<center><B>zNumbers Rules</B></center><BR><B>Goal: </B>Move every block once<BR><B>Movement: </B>Every block can be moved horizontally, vertically or diagonally. The number on the block indicates how far the block must be moved.");
			rbox->setMaximumWidth(210);
			rbox->show();
		break;
		case NEW_RAND_LEVEL:
			board->randLevel();
			board->saveLevel();
		break;
		case RESTART_LEVEL:
			board->loadLevel();
		break;
		case LEVELNUM:
			levelNum = 0;
		break;
		case LEVELNUM+1:
			levelNum = 1;
		break;
		case LEVELNUM+2:
			levelNum = 2;
		break;
		case LEVELNUM+3:
			levelNum = 3;
		break;
		case LEVELNUM+4:
			levelNum = 4;
		break;
		case LEVELNUM+5:
			levelNum = 5;
		break;
		case LEVELNUM+6:
			levelNum = 6;
		break;
		case LEVELNUM+7:
			levelNum = 7;
		break;
		case LEVELNUM+8:
			levelNum = 8;
		break;
		case LEVELNUM+9:
			levelNum = 9;
		break;
		default:
		break;
	}
	if (levelNum >= 0) {
		for (int x=0; x<6; x++)
			for (int y=0; y<6; y++)
				board->setLevel(x, y, level[levelNum][y][x]);
		board->saveLevel();
	}

	board->startLevel();
}
