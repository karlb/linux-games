#include <FL/Fl.H>                                                              
#include <FL/Fl_Pixmap.H>
#include <FL/fl_message.H>
#include <flpda/Widget_Factory.h>
#include <flpda/gettext.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>

#include <Fl/Fl_Box.H>

// levels
#include "levels.h"

// pics
#include "p1.xpm"
#include "p2.xpm"
#include "p3.xpm"
#include "p4.xpm"
#include "p1_moved.xpm"
#include "p2_moved.xpm"
#include "p3_moved.xpm"
#include "p4_moved.xpm"
#include "possible.xpm"

const int N_SIZE = 24;
const int N_TYPE = 10;
const int MAX_N_X = 10;
const int MAX_N_Y = 10;

int N_X = 6;
int N_Y = 6;

Fl_Button* done_button, *restart_button, *about_button;
Fl_Menu_Button* levelButton;
char LevelText[20]="Random";

// PieceMap Class
class PieceMap {
protected:
    int selectedx, selectedy, selectedtype;
    int score, rest;
    char map[MAX_N_Y][MAX_N_X];
    char old_map[MAX_N_Y][MAX_N_Y];
    int newblock;
public:
    int levelnum;

    bool trymove(int x, int y) {
    
        if ( (x < 0) || (x >= N_X) ) return 1;
        if ( (y < 0) || (y >= N_X) ) return 1;
      
        if (map[y][x] == 0) {
    	    map[y][x] = newblock;
	    rest += 1;
    	    return false;
        }
	return true;
    }

    void generate_map() {
	if (levelnum == 10) {
	    // random level
	    for (int y = 0; y < N_Y; y++) {
		for (int x = 0; x < N_X; x++) {
	            map[y][x]=0;
	        }
            }
	    for (int y = 0; y < N_Y; y++) {
	        for (int x = 0; x < N_X; x++) {
    	      	    do {
			newblock = (rand() % (5));
		    } while ( (newblock != 0) && (map[y][x] == 0) 
			    && trymove(x-newblock,y) && trymove(x,y-newblock) 
			    && trymove(x,y+newblock) && trymove(x+newblock,y)
			    && trymove(x-newblock,y-newblock) && trymove(x+newblock,y-newblock) 
			    && trymove(x+newblock,y+newblock) && trymove(x+newblock,y-newblock) );
		}
	    }
	} else {
	    // normal level
	    for (int y = 0; y < N_Y; y++) {
		for (int x = 0; x < N_X; x++) {
		    map[y][x]=level[levelnum][y][x];
		    if (map[y][x]>0) rest++;
		}
	    }
        }
    }

public:
  PieceMap() {
    score = 0;
    selectedx = selectedy = selectedtype = -1;
    rest = 0;
    levelnum = 10;

    srand(time(0) + getpid());
    generate_map();
  }
};

static char** PIXMAPS[N_TYPE] = { NULL, p1_xpm, p2_xpm, p3_xpm, p4_xpm, p1_moved_xpm, p2_moved_xpm, p3_moved_xpm, p4_moved_xpm, possible_xpm };

class gameWidget : public PieceMap, public Fl_Group {
  class Point {
  public:
    int x, y;

    Point()
    {
      this->x = 0;
      this->y = 0;
    }
    Point(int x, int y)
    {
      this->x = x;
      this->y = y;
    }
  };

  class Location : public Point {
  public:
    gameWidget* s;

    Location(int x, int y, gameWidget* s) : Point(x, y)
    {
      this->s = s;
    }
  };

  Fl_Button* button[MAX_N_Y][MAX_N_X];
  Fl_Pixmap* pixmap_piece[N_TYPE];

public:
  gameWidget(int x, int y, int w, int h) : PieceMap(), Fl_Group(x, y, w, h)
  {
    for (int i = 1; i < N_TYPE; i++) {
      pixmap_piece[i] = new Fl_Pixmap(PIXMAPS[i]);
    }

    new Fl_Box(10, 10, 140, 10, "Move every block once!");
    for (int y = 0; y < N_Y; y++) {
      for (int x = 0; x < N_X; x++) {
	button[y][x] = new Fl_Button(x*N_SIZE + 80-N_SIZE/2*N_X , y*N_SIZE+ 100-N_SIZE/2*N_Y, 
				     N_SIZE, N_SIZE, "");
	button[y][x]->box(FL_BORDER_BOX);
        button[y][x]->callback(button_cb, new Location(x, y, this));
      }
    }
    printMap();
  }

  void showIfPossible(int x, int y) {
  
      if ( (x < 0) || (x >= N_X) ) return;
      if ( (y < 0) || (y >= N_X) ) return;
      
      if (map[y][x] == 0) {
          map[y][x] = -1;
      }
  }

  static void button_cb(Fl_Widget* widget, void* data)
  {
    Location* loc = reinterpret_cast<Location*>(data);
    gameWidget* s = loc->s;
    int type = s->map[loc->y][loc->x];

    if (type>4) return;    
    if (type>0) {
	// Select number
	s->selectedx = loc->x;
        s->selectedy = loc->y;
        s->selectedtype = type;
	
        // Erase possibilities
	for (int y = 0; y < N_Y; y++)
	    for (int x = 0; x < N_X; x++)
	        if (s->map[y][x] == -1) {
	    	s->map[y][x] = 0;
    	    }

	// Show possibilities
	s->showIfPossible(loc->x+type, loc->y);
	s->showIfPossible(loc->x, loc->y+type);
	s->showIfPossible(loc->x-type, loc->y);
	s->showIfPossible(loc->x, loc->y-type);

	s->showIfPossible(loc->x+type, loc->y+type);
	s->showIfPossible(loc->x-type, loc->y+type);
	s->showIfPossible(loc->x-type, loc->y-type);
	s->showIfPossible(loc->x+type, loc->y-type);
    } else {
	// Move number    
	if  (
		(s->selectedtype>0) &&
		(
		      ( (loc->x == s->selectedx) && (abs(loc->y - s->selectedy) == s->selectedtype) )
		    ||( (loc->y == s->selectedy) && (abs(loc->x - s->selectedx) == s->selectedtype) )
		    ||( (abs(loc->x - s->selectedx) == s->selectedtype) && (abs(loc->y - s->selectedy) == s->selectedtype) )
		)
	    ) {
	    s->map[loc->y][loc->x] = s->map[s->selectedy][s->selectedx]+4;
	    s->map[s->selectedy][s->selectedx] = 0;
	    s->selectedx = -1;
	    s->selectedy = -1;
	    s->selectedtype = -1;
	    s->rest--;

    	    // Erase possibilities
	    for (int y = 0; y < N_Y; y++)
		for (int x = 0; x < N_X; x++)
	    	    if (s->map[y][x] == -1) {
	    		s->map[y][x] = 0;
    		    }
		    
	    // Check for game end
    	    if (s->rest == 0) s->gameOver();
	}
    }
    s->printMap();
  }

  void restart()
  {
      selectedx = -1;
      selectedy = -1;
      selectedtype = -1;
      score = 0;
      rest = 0;
      generate_map();
  }

/*  void setSize(int nx, int ny)
  {
      for (int y = 0; y < N_Y; y++) {
          for (int x = 0; x < N_X; x++) {
	      button[x][y]->clear();
	      delete(button[x][y]);
          }
      }
      N_X = nx;
      N_Y = ny;
      for (int y = 0; y < N_Y; y++) {
          for (int x = 0; x < N_X; x++) {
	      button[y][x] = new Fl_Button(x*N_SIZE + 80-N_SIZE/2*N_X, y*N_SIZE+ 100-N_SIZE/2*N_Y, 
				     N_SIZE, N_SIZE, "");
	      button[y][x]->box(FL_BORDER_BOX);
    	      button[y][x]->callback(button_cb, new Location(x, y, this));
          }
      }
      restart();
      printMap();
  }*/

  int printMap()
  {
    for (int y = 0; y < N_Y; y++) {
        for (int x = 0; x < N_X; x++) {
	    if (old_map[y][x] != map[y][x]) {
		old_map[y][x] = map[y][x];
	        if (map[y][x] == -1) {
	    	    pixmap_piece[9]->label(button[y][x]);
	        } else
	            pixmap_piece[map[y][x]]->label(button[y][x]);
	        button[y][x]->redraw();
	    }
	    if ((selectedx == x) && (selectedy == y)) {
		pixmap_piece[map[y][x]+4]->label(button[y][x]);
		old_map[y][x] += 4;
	    }
	}
    }
  }

    void gameOver()
    {
        printMap();
        fl_message("\nCongratulations!\n\nYou've won.");
//        if (levelnum<10) levelnum++;
//        restart();
    }
};

void done_cb(Fl_Widget* widget, void* data)
{
    Fl_Window* window;
    
    window = widget->window();
    while((window = window->window())->parent() != 0);
    window->hide();
}

class About_Dialog {
public:
About_Dialog(const char* application, const char* version)
{
	Fl_App_Window* window = Widget_Factory::new_window(_("About"));
	window->set_modal();

	Fl_Browser* b = Widget_Factory::new_select_browser(0, 0,
		Fl_Group::current()->w(), Fl_Group::current()->h());
	Fl_Group::current()->resizable(b);
	b->callback(done_cb, window);
	b->add("");
	char msg[256];
	sprintf(msg, "@c@b%s %s", application, version);
	b->add(msg);
	b->add("");

	b->add("@cCopyright (C) 2001");
	b->add("@cKarl Bartel");
	b->add("@cwww.linux-games.com");

#ifdef RESTRICTED_LICENSE
	b->add("");
	b->add("@cThis product is licensed.");
#else
	b->add("");
	b->add("@cLicensed under the");
	b->add("@cGNU General Public License.");
	b->add("@cThis is free software, and you");
	b->add("@care welcome to redistribute it");
	b->add("@cunder certain conditions.");
#endif

	b->add("");
	sprintf(msg, "@c%s comes with", application);
	b->add(msg);
	b->add("@cABSOLUTELY NO WARRANTY.");

	window->end();

	Fl_Dockable_Window* toolbar = Widget_Factory::new_toolbar();
	Widget_Factory::new_button(_("Done"), done_cb, window);
	toolbar->end();

	window->add_dockable(toolbar, 1);

	window->show();
}
};

gameWidget* game;

void about_cb(Fl_Widget* widget, void* data)
{
    char version[64];
    sprintf(version, "%d.%d", VERSION, PATCHLEVEL);
    new About_Dialog(_("Numbers"), version);
}

void restart_cb(Fl_Widget* widget, void* data)
{
    game->restart();
    game->printMap();
}

/*void size_cb(Fl_Widget* widget, void* data)
{
    game->setSize(3,3);
}*/

static void level_cb(Fl_Widget* s, void *data) {

    game->levelnum=levelButton->value();    
    game->restart();
    game->printMap();
    if ( levelButton->value() < 10 ) {
	sprintf(LevelText,"Level %d",levelButton->value()+1);
    } else {
	sprintf(LevelText,"%s","Random");
    }
    levelButton->redraw();
}

void createLevelSelect() {
    levelButton = WidgetFactory::new_menu_button(LevelText, level_cb);
    levelButton->align(FL_ALIGN_INSIDE | FL_ALIGN_LEFT);
    levelButton->resize(0, 0,  65, WidgetFactory::buttonheight());
    Fl_Menu_Item items[] = {
        {"Level 1"},
        {"Level 2"},
        {"Level 3"},
        {"Level 4"},
        {"Level 5"},
        {"Level 6"},
        {"Level 7"},
        {"Level 8"},
        {"Level 9"},
        {"Level 10"},
	{"Random"},{0}
    };
    levelButton->copy(items);
}

int main(int argc, char **argv)
{
    Fl_App_Window* window = WidgetFactory::new_window("Numbers");

    game = new gameWidget(0, 0, window->w(), window->h());
    window->end();
  
    Fl_Dockable_Window* toolbar = WidgetFactory::new_toolbar();
    done_button = WidgetFactory::new_button(_("Done"), done_cb, 0);
    restart_button = WidgetFactory::new_button(_("New"), restart_cb, 0);
    about_button = WidgetFactory::new_button(_("About"), about_cb, 0);
/*    Fl_Menu_Button* menu = WidgetFactory::new_menu_button("Level");
    menu->add(_("4x4"), 0, size_cb, 0);
    menu->add(_("5x5"), 0, size_cb, 0);
    menu->add(_("6x6"), 0, size_cb, 0);
    toolbar->end();*/
    createLevelSelect();
    window->add_dockable(toolbar, 1);
  
    window->show();
    return Fl::run();
}
