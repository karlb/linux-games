#include <qpainter.h>
#include <qmenubar.h>
#include <qapplication.h>
#include <qmessagebox.h>
#include <string.h>

#include "app_window.h"
#include "board.h"

#define str(s) xstr(s)
#define xstr(s) #s
#define appName zChain

AppWindow::AppWindow( QWidget* parent, const char* name, WFlags f )
	: QMainWindow( parent, name, f )
{
	setCaption(str(appName));
	playerID = 0;

	board = new Board(this);
	board->setGeometry(8, 55, 224, 224);
	connect(board, SIGNAL(showPlayer(int)), SLOT(showPlayer(int)));

	QMenuBar *mb=menuBar();

    appMenu = new QPopupMenu;
	appMenu->insertItem( "&About", ABOUT);
	appMenu->insertItem( "&Rules", RULES);
	appMenu->insertSeparator();
	appMenu->insertItem( "&Exit", EXIT);
	mb->insertItem(str(&appName), appMenu);
	connect( appMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
    levelMenu = new QPopupMenu;
	levelMenu->insertItem( "&2 Player Game", PLAYERNUM + 0);
	levelMenu->insertItem( "&3 Player Game", PLAYERNUM + 1);
	levelMenu->insertItem( "&4 Player Game", PLAYERNUM + 2);
	mb->insertItem("&New Game", levelMenu);
	connect( levelMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
	
	board->color[0] = QColor(255, 0, 0);
	board->color[1] = QColor(0, 0, 255);
	board->color[2] = QColor(0, 255, 0);
	board->color[3] = QColor(0, 255, 255);
}

void AppWindow::paintEvent ( QPaintEvent * )
{
	QPixmap tpix(width(),height());
	tpix.fill(QColor(199,190,166));
	
	QPainter p(this);
	p.drawPixmap(0,0,tpix);

	char player[20], text[50];
	
	switch (playerID) {
		default:
		case 0:
			strcpy(player, "Red");
		break;
		case 1:
			strcpy(player, "Blue");
		break;
		case 2:
			strcpy(player, "Green");
		break;
		case 3:
			strcpy(player, "Cyan");
		break;
	}
	sprintf(text, "%s player's turn", player);
	
	p.setPen(board->color[playerID]);
	p.setFont( QFont("helvetica", 20));
	p.drawText(10, 45, QString(text));
	
	

}

void AppWindow::showPlayer(int player)
{
	playerID = player;
	paintEvent(NULL);
}


void AppWindow::menuSelected(int id)
{
	switch(id) {
		case EXIT:
			close();
		break;
		case ABOUT:
			QMessageBox *abox;
			abox = new QMessageBox(this, "About");
			abox->setText("<center><B>zChain</B><BR>www.linux-games.com<BR><BR>(c) 2002 by Karl Bartel<BR>This is free Software (GPL)</center>");
			abox->show();
		break;
		case RULES:
			QMessageBox *rbox;
			rbox = new QMessageBox(this, "Rules");
			rbox->setText("<center><B>zChain Rules</B></center><BR>Each turn you may choose one empty square, or a square you own. The value of the chosen square is incremented and if the square was empty, you are the new owner. "
				      "If the value of a square gets bigger than the number of adjacent squares, it explodes. This means that the value is reduced by the number of adjacent squares, all adjacent squares become your squares and their value is incremented.<Br>"
				      "If a player loses all his squares, he may take no more turns. The last player standing wins.");
			rbox->setMaximumWidth(210);
			rbox->show();
		break;
		case PLAYERNUM + 0:
		case PLAYERNUM + 1:
		case PLAYERNUM + 2:
			board->newGame(id - PLAYERNUM + 2);
		break;
		default:
		break;
	}
}
