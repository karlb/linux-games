#ifndef BOARD_H
#define BOARD_H

#include <qwidget.h>
#include <qbitmap.h>
#include <qtimer.h>
#include <qpoint.h>
#include <qlist.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>
#include <qtimer.h>
#include <qpixmap.h>
#include <qpe/resource.h>

class Board : public QWidget
{
	Q_OBJECT

public:
	Board(QWidget* parent=0, const char* name=0, WFlags f=0 );
	void newGame(int playerNum);
	int count(int player);
	QColor color[4];

signals:
	void showPlayer(int);

protected:
	void paintEvent ( QPaintEvent * );
	void mousePressEvent ( QMouseEvent * ); 

private:
	QPixmap exploPic[4], emptyPic;
	int map[7][7], owner[7][7], max[7][7];
	int player, curPlayer, playerCount, lastLivingPlayer;
	int blockWidth, blockHeight;
	bool firstTurn;

	bool allSelected();
	bool finished();
	bool alive(int player);
	void safeInc(int x, int y);
	void check(int x, int y);
	QPixmap loadPixmap(char *file);
};

#endif
