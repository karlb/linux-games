#include <unistd.h>
#include <qpainter.h>
#include <qmessagebox.h> 

#include "board.h"

const char xblocks = 7, yblocks = 7, blockTypes = 1;

Board::Board(QWidget* parent, const char* name, WFlags f ): QWidget(parent,name,f)
{
	char filename[200];

	emptyPic = loadPixmap("ground");

	for (int i=0; i<4; i++) {
		sprintf(filename, "explo%d", i);
		exploPic[i] = loadPixmap(filename);
	}

	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			map[x][y] = 0;
	
	blockWidth  = emptyPic.width();
	blockHeight = emptyPic.height();
	
	for (int x=1; x<6; x++)
		for (int y=1; y<6; y++)
			max[x][y] = 4;

	for (int x=1; x<7; x++) {
		max[x][0] = 3;
		max[x][6] = 3;
	}

	for (int y=1; y<7; y++) {
		max[0][y] = 3;
		max[6][y] = 3;
	}
	
	max[0][0] = 2;
	max[0][6] = 2;
	max[6][0] = 2;
	max[6][6] = 2;

	newGame(2);
}

void Board::newGame(int playerNum)
{
	playerCount = playerNum;
	firstTurn = true;
	
	for (int x=0; x<xblocks; x++) {
		for (int y=0; y<yblocks; y++) {
			map[x][y] = 0;
			owner[x][y] = -1;
		}
	}
	
	lastLivingPlayer = -1;
	curPlayer = 0;
	paintEvent(NULL);
}

bool Board::alive(int player)
{
	if (firstTurn)
		return true;

	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			if (owner[x][y] == player)
				return true;

	return false;	
}


void Board::paintEvent ( QPaintEvent *pe) 
{
	
	QPainter p(this);

	p.setFont( QFont( "courier", 35 ) );
	for (int x=0; x<xblocks; x++) {
		for (int y=0; y<yblocks; y++) {
			QColor col;
			
			if (!map[x][y]) {
				
				col = QColor(0, 0, 0);
				
			} else switch (owner[x][y]) {
				case 0:
					col = QColor(255, 0, 0);
				break;
				case 1:
					col = QColor(0, 0, 255);
				break;
				case 2:
					col = QColor(0, 255, 0);
				break;
				case 3:
					col = QColor(0, 255, 255);
				break;
				default:
					puts("Ooops, wrong player");
				break;
				
			}
			p.setPen(col);
			p.drawPixmap(blockWidth*x, blockHeight*y, emptyPic);
			char text[2];
			
			sprintf(text, "%d", map[x][y]);
			p.drawText(blockWidth*x+9, blockHeight*(y+1)-5, QString(text));
		}
	}
	
}

bool Board::finished()
{
	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			if (!map[x][y])
				return false;
	
	return true;
}

int Board::count(int player)
{
	int ret = 0;

	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			if (owner[x][y] == player)
				ret += map[x][y];
			
	return ret;
}

void Board::safeInc(int x, int y)
{
	if (x < 0 || x > 6 || y < 0 || y > 6)
		return;
	
	owner[x][y] = curPlayer;
	map[x][y]++;
}

void Board::check(int x, int y)
{
	if (x < 0 || x > 6 || y < 0 || y > 6)
		return;
	
	bool end = true;	
	for (int i=0; i<playerCount; i++)
		if (i != curPlayer && alive(i))
			end = false;
			
	if (end)
		return;

	if (map[x][y] > max[x][y]) {
		
		safeInc(x-1, y);
		safeInc(x+1, y);
		safeInc(x, y-1);
		safeInc(x, y+1);
	
		paintEvent(NULL);
		QPainter p(this);
		p.drawPixmap(blockWidth*(x-1), blockHeight*(y-1), exploPic[curPlayer]);
		QTimer t(this);
		t.start(0);
		usleep(700000);
		map[x][y] -= max[x][y];
	
		check(x-1, y);
		check(x+1, y);
		check(x, y-1);
		check(x, y+1);
		
	}
}

void Board::mousePressEvent ( QMouseEvent *e )
{
	int x = e->x() / blockWidth;
	int y = e->y() / blockHeight;
	
	if (owner[x][y] != curPlayer && owner[x][y] != -1)
		return;
	
	safeInc(x,y);
	check(x,y);

	// next player
	do {
		curPlayer++;
		if (curPlayer == playerCount) {
			curPlayer = 0;
			firstTurn = false;
		}
			
	} while (!alive(curPlayer));

	// do we have a winner?
	if (lastLivingPlayer == curPlayer) {
		char text[80], player[20];
		switch(curPlayer) {
			case 0:
				strcpy(player, "Red");
			break;
			case 1:
				strcpy(player, "Blue");
			break;
			case 2:
				strcpy(player, "Green");
			break;
			case 3:
				strcpy(player, "Cyan");
			break;
		}
		sprintf(text, "<center><nobr><b>%s player has won!</b></nobr></center>", player);

		paintEvent(NULL);
		QMessageBox *abox;
		abox = new QMessageBox(this, "Won!");
		abox->setText(text);
		abox->setButtonText(1, "Play again");
		abox->exec();
		newGame(playerCount);
	} else {
		lastLivingPlayer = curPlayer;
	}

	emit showPlayer(curPlayer);

	// draw
	paintEvent(NULL);
}

QPixmap Board::loadPixmap(char *file)
{
	const char appName[] = "zchain";
	const char GFX_PATH[] = "ipk/opt/QtPalmtop/pics";

	if (getenv("XAUTHORITY") == NULL) {
		char filename[80];
		sprintf(filename, "%s/%s", appName, file);

		return Resource::loadPixmap(filename);
	} else {
		char filename[80];
		QPixmap *ret;
		ret = new QPixmap;
	
		sprintf(filename, "%s/%s/%s.png", GFX_PATH, appName, file);
		if (!ret->load(filename))
			printf("Couldn't load %s\n",filename);
			
		return *ret;
	}
}

