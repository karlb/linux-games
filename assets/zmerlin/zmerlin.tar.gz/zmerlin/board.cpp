#include "board.h"
#include <qpainter.h>
#include <qmessagebox.h> 

const char xblocks = 3, yblocks = 3, blockTypes = 1;

Board::Board(QWidget* parent, const char* name, WFlags f ): QWidget(parent,name,f)
{
	penguinPic = loadPixmap("penguin");
	emptyPic = loadPixmap("ground");

	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			map[x][y] = 0;
	
	blockWidth  = emptyPic.width();
	blockHeight = emptyPic.height();
	
	buffer = new QPixmap(225, 225);
	
	srand(time(NULL));
	startLevel();
	
}

void Board::startLevel()
{
	paintEvent(NULL);
	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			map[x][y] = rand() % 2;
}

void Board::paintEvent ( QPaintEvent *pe) 
{
	
	QPainter p(buffer);
	p.moveTo(0,0);

	for (int x=0; x<xblocks; x++) {
		for (int y=0; y<yblocks; y++) {
			p.drawPixmap(blockWidth*x, blockHeight*y, emptyPic);
			if (map[x][y]) 
				p.drawPixmap(blockWidth*x, blockHeight*y, penguinPic);
		}
	}
	
	QPainter final(this);
	final.drawPixmap(0, 0, *buffer);
	
}

bool Board::finished()
{
	for (int x=0; x<xblocks; x++)
		for (int y=0; y<yblocks; y++)
			if (!map[x][y])
				return false;
	
	return true;
}

void Board::invert(int x, int y)
{
	map[x][y] = 1-map[x][y];
}

void Board::mousePressEvent ( QMouseEvent *e )
{
	int x = e->x() / blockWidth;
	int y = e->y() / blockHeight;

	invert(x,y);
	// corners
	if (x==0 && y==0) {
		invert(0,1);
		invert(1,0);
		invert(1,1);
	}
	if (x==2 && y==2) {
		invert(2,1);
		invert(1,2);
		invert(1,1);
	}
	if (x==2 && y==0) {
		invert(1,0);
		invert(2,1);
		invert(1,1);
	}
	if (x==0 && y==2) {
		invert(0,1);
		invert(1,2);
		invert(1,1);
	}

	// middle
	if (x==1 && y==1) {
		invert(0,1);
		invert(1,0);
		invert(2,1);
		invert(1,2);
	}

	// sides
	if (x==1 && y==0) {
		invert(0,0);
		invert(2,0);
	}
	if (x==1 && y==2) {
		invert(0,2);
		invert(2,2);
	}
	if (x==2 && y==1) {
		invert(2,0);
		invert(2,2);
	}
	if (x==0 && y==1) {
		invert(0,2);
		invert(0,0);
	}

	if (finished()) {
		paintEvent(NULL);
		QMessageBox *abox;
		abox = new QMessageBox(this, "Won!");
		abox->setText("<center><b>Congratulations</b><BR><BR>You solved it!</center>");
		abox->setButtonText(1, "Try again");
		abox->exec();
		startLevel();
	}

	paintEvent(NULL);
}

QPixmap Board::loadPixmap(char *file)
{
	const char appName[] = "zmerlin";
	const char GFX_PATH[] = "ipk/opt/QtPalmtop/pics";

	if (getenv("XAUTHORITY") == NULL) {
		char filename[80];
		sprintf(filename, "%s/%s", appName, file);

		return Resource::loadPixmap(filename);
	} else {
		char filename[80];
		QPixmap *ret;
		ret = new QPixmap;
	
		sprintf(filename, "%s/%s/%s.png", GFX_PATH, appName, file);
		if (!ret->load(filename))
			printf("Couldn't load %s\n",filename);
			
		return *ret;
	}
}

