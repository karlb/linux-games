#ifndef BOARD_H
#define BOARD_H

#include <qwidget.h>
#include <qbitmap.h>
#include <qtimer.h>
#include <qpoint.h>
#include <qlist.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>
#include <qtimer.h>
#include <qpixmap.h>
#include <qpe/resource.h>

class Board : public QWidget
{
	Q_OBJECT

public:
	Board(QWidget* parent=0, const char* name=0, WFlags f=0 );
	void startLevel();

protected:
	void paintEvent ( QPaintEvent * );
	void mousePressEvent ( QMouseEvent * ); 

private:
	QPixmap penguinPic, wonPic, emptyPic;
	QPixmap *buffer;
	int map[3][3];
	int blockWidth, blockHeight;

	bool allSelected();
	bool finished();
	void invert(int x, int y);
	QPixmap loadPixmap(char *file);
};

#endif
