/****************************************************************************
** Form interface generated from reading ui file 'highscore/input.ui'
**
** Created: Thu Sep 12 20:45:15 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef INPUT_H
#define INPUT_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QLineEdit;

class input : public QDialog
{ 
    Q_OBJECT

public:
    input( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~input();

    QLineEdit* LineEdit1;
    QLabel* TextLabel1;

public slots:
    virtual void setName(const QString&);

protected:
    bool event( QEvent* );
};

#endif // INPUT_H
