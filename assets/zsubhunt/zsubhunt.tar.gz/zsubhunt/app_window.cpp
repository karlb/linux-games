#include <qpainter.h>
#include <qmenubar.h>
#include <qapplication.h>
#include <qmessagebox.h>

#include "app_window.h"
#include "board.h"

#define str(s) xstr(s)
#define xstr(s) #s
#define appName zSubHunt

AppWindow::AppWindow( QWidget* parent, const char* name, WFlags f )
	: QMainWindow( parent, name, f )
{
	setCaption(str(appName));
	srand(time(NULL));

	board = new Board(this);
	board->setGeometry(0, 20, 240, 265);

	QMenuBar *mb=menuBar();

    appMenu = new QPopupMenu;
	appMenu->insertItem( "&About", ABOUT);
	appMenu->insertItem( "&Rules", RULES);
	appMenu->insertSeparator();
	appMenu->insertItem( "&Exit", EXIT);
	mb->insertItem(str(&appName), appMenu);
	connect( appMenu, SIGNAL(activated(int)),SLOT(menuSelected(int))); 
    levelMenu = new QPopupMenu;
	levelMenu->insertItem( "&Pause Game", PAUSE_GAME);
	levelMenu->insertItem( "&Unpause Game", UNPAUSE_GAME);
	levelMenu->insertSeparator();
	levelMenu->insertItem( "&Easy Game", LEVELNUM+0);
	levelMenu->insertItem( "&Normal Game", LEVELNUM+1);
	levelMenu->insertItem( "&Hard Game", LEVELNUM+2);
	levelMenu->insertSeparator();
	levelMenu->insertItem( "&Show HighScores (easy)", HIGHSCORE1);
	levelMenu->insertItem( "&Show HighScores (normal)", HIGHSCORE2);
	levelMenu->insertItem( "&Show HighScores (hard)", HIGHSCORE3);
	mb->insertItem("&Game", levelMenu);
	connect( levelMenu, SIGNAL(activated(int)),SLOT(menuSelected(int)));
}

void AppWindow::menuSelected(int id)
{
	switch(id) {
		case EXIT:
			close();
		break;
		case ABOUT:
			QMessageBox *abox;
			abox = new QMessageBox(this, "About");
			abox->setText("<center><B>zSubHunt</B><BR>www.linux-games.com<BR><BR>(c) 2002 by Karl Bartel<BR>This is free Software (GPL)</center>");
			board->stop();
			abox->exec();
			board->start();
		break;
		case RULES:
			QMessageBox *rbox;
			rbox = new QMessageBox(this, "Rules");
			rbox->setText("<center><B>zSubHunt Rules</B></center><BR><b>Goal:</b> Don't let the submarines pass!<BR><b>Scoring:</b> For every destroyed sub you get between 60 and 250 points, depending on its depth. Every bomb costs 10.<BR><b>Lives:</b> Every time a sub passes without beeing destroyed, you lose one live.");
			rbox->setMaximumWidth(210);
			board->stop();
			rbox->exec();
			board->start();
		break;
		case PAUSE_GAME:
			board->stop();
		break;
		case UNPAUSE_GAME:
			board->start();
		break;
		case LEVELNUM:
		case LEVELNUM+1:
		case LEVELNUM+2:
			board->startLevel(id-LEVELNUM);
		break;
		case HIGHSCORE1:
		case HIGHSCORE2:
		case HIGHSCORE3:
			board->stop();
			board->highScore[id-HIGHSCORE1]->showScore();
			board->start();
		break;
		default:
		break;
	}
}

