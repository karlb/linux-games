#include "board.h"
#include <qpainter.h>
#include <qmessagebox.h>
#include <qnamespace.h>
#include <qevent.h>
#include <qpixmap.h>
#include <qpe/resource.h>
#include <stdlib.h>

const char maxBombs = 3;
const int  skyHeight = 40, fps = 50, waterPicNumber = 8;

QPixmap Board::loadPixmap(char *file)
{
	const char appName[] = "zsubhunt";
	const char GFX_PATH[] = "ipk/opt/QtPalmtop/pics";

	if (getenv("XAUTHORITY") == NULL) {
		char filename[80];
		sprintf(filename, "%s/%s", appName, file);

		return Resource::loadPixmap(filename);
	} else {
		char filename[80];
		QPixmap *ret;
		ret = new QPixmap;
	
		sprintf(filename, "%s/%s/%s.png", GFX_PATH, appName, file);
		if (!ret->load(filename))
			printf("Couldn't load %s\n",filename);
			
		return *ret;
	}
}

Board::Board(QWidget* parent, const char* name, WFlags f ): QWidget(parent,name,f)
{
	char filename[50];
	
	QPixmap::setDefaultOptimization(QPixmap::BestOptim);
	for (int i=0; i<waterPicNumber; i++) {
		sprintf(filename, "water%d", i+1);
		waterPic[i] = loadPixmap(filename);
	}

	skyPic = loadPixmap("sky");
	destroyerPic = loadPixmap("destroyer");
	livesPic = loadPixmap("lives");
	subPic = loadPixmap("sub");
	bombPic = loadPixmap("bomb");

	highScore[0] = new HighScore(this, "zSubHunt (easy)");
	highScore[1] = new HighScore(this, "zSubHunt (normal)");
	highScore[2] = new HighScore(this, "zSubHunt (hard)");

	destroyerX = 120 - destroyerPic.width()/2;

	leftPressed = false;
	rightPressed = false;
	
	setFocusPolicy(QWidget::StrongFocus);
//	grabKeyboard ();
	buffer = new QPixmap(240, 265);
	
	mainTimer = new QTimer(this, "mainTimer");
	mainTimer->start(1000 / fps);
	connect(mainTimer, SIGNAL(timeout()), SLOT(gameLogic()));

	newSubTimer = new QTimer(this, "newSubTimer");
	newSubTimer->start(subInterval);
	connect(newSubTimer, SIGNAL(timeout()), SLOT(newSub()));

	waterCount = 0;
	startLevel(1);
	stop();
}

Board::~Board()
{
	delete highScore[0];
	delete highScore[1];
	delete highScore[2];
}

void Board::start()
{
	if (lost)
		return;
	mainTimer->start(1000 / fps);
	newSubTimer->start(subInterval);
}

void Board::stop()
{
	mainTimer->stop();
	newSubTimer->stop();
}

void Board::gameLogic()
{
	if (leftPressed && destroyerX > 0)
		destroyerX -= 100 / fps;
	if (rightPressed && destroyerX+destroyerPic.width() < 240)
		destroyerX += 100 / fps;
	
	for (int i=0; i<subCount; i++) {
		sub[i]->x += sub[i]->speed / fps;
		if ((sub[i]->x < -subPic.width()) || (sub[i]->x > 240)) {
			delete sub[i];
			sub[i] = sub[--subCount];
			
			//score -= 100;
			lives--;
			
			if (lives < 0) {
				stop();
				QMessageBox *box;
				box = new QMessageBox(this, "endBox");
				char text[150];
				sprintf(text,"<center><b>Game Over</b><BR> Your final score: %d</center>", score);
				box->setText(text);
				box->setMinimumWidth(110);
				box->exec();
				lost = true;
				highScore[difficulty]->addScore(score);
			}
		}
	}

	for (int i=0; i<bombCount; i++) {
		bomb[i]->y += bomb[i]->speed / fps;
		if (bomb[i]->y > 265) {
			delete bomb[i];
			bomb[i] = bomb[--bombCount];
		}
	}

	for (int i=0; i<numberCount; i++) {
		number[i]->y += number[i]->speed / fps;
		number[i]->time -= 1;
		if (number[i]->time <= 0) {
			delete number[i];
			number[i] = number[--numberCount];
		}
	}
	
	for (int b=0; b<bombCount; b++) {
		for (int s=0; s<subCount; s++) {
			static const int topoverlap = 5, leftoverlap = 1, rightoverlap = 1, bottomoverlap = 1;
		
			if ( ((bomb[b]->x+bombPic.width()-leftoverlap > sub[s]->x) && (bomb[b]->x < sub[s]->x+subPic.width()-rightoverlap)) &&
			     ((bomb[b]->y+bombPic.height()-topoverlap > sub[s]->y) && (bomb[b]->y < sub[s]->y+subPic.height()-bottomoverlap)) )
			{
				number[numberCount++] = new Number(bomb[b]->x, bomb[b]->y, int(sub[s]->y), 100);

				score += int(sub[s]->y);
				delete bomb[b];
				bomb[b] = bomb[--bombCount];
				delete sub[s];
				sub[s] = sub[--subCount];
			}
		}
	}
		
	waterCount += 0.1;
	if ((int)waterCount == waterPicNumber)
		waterCount -= waterPicNumber;
	
	paintEvent(NULL);
}

void Board::newSub()
{
	int movesRight = rand() % 2;
	int y = rand() % 190 + 60;
	float speed = rand() % 20 + 36 - y/8;

	sub[subCount++] = new Sub(movesRight ? -subPic.width() : 240, y, movesRight ? speed : -speed);

	subInterval -= subInterval/150;
	newSubTimer->changeInterval(subInterval);
}

void Board::newBomb()
{
	bomb[bombCount++] = new Bomb(destroyerX + destroyerPic.width()/2, skyHeight, 30);
}

void Board::startLevel(int newDifficulty)
{
	paintEvent(NULL);
	subCount = 0;
	bombCount = 0;
	score = 0;
	lives = 3;
	subInterval = 4500 - newDifficulty * 1000;
	difficulty = newDifficulty;
	lost = false;
	start();
}

void Board::keyPressEvent( QKeyEvent *e )
{
	switch (e->key()) {
		case Key_Left:
			leftPressed = true;
		break;
		case Key_Right:
			rightPressed = true;
		break;
		case Key_Return:
		case Key_Space:
		case Key_Control:
			if (bombCount < maxBombs) {
				newBomb();
				score -= 10;
			}
		break;
		default:
		break;
	}
}

void Board::keyReleaseEvent( QKeyEvent *e )
{
	switch (e->key()) {
		case Key_Left:
			leftPressed = false;
		break;
		case Key_Right:
			rightPressed = false;
		break;
		default:
		break;
	}
}

void Board::paintEvent ( QPaintEvent *pe) 
{
	if (pe == NULL) {
	}
	QPainter p(buffer);

	// Background
	p.drawPixmap(0, 0, skyPic);
	p.drawPixmap(0, skyHeight, waterPic[(int)waterCount]);
	
	// Destroyer
	p.drawPixmap(destroyerX, 10, destroyerPic);
	
	// Score
	if (score < 0)
		score = 0;
	QString text;
	text.sprintf("Score: %d", score);
	p.drawText(3, 12, text);

	// Lives
	for (int i=0; i< lives; i++)
		p.drawPixmap(120 + i*(livesPic.width()+3) - lives*(livesPic.width()+3)/2, 3, livesPic);

	// Subs
	for (int i=0; i<subCount; i++)
		p.drawPixmap(sub[i]->x, sub[i]->y, subPic);

	// Bombs
	for (int i=0; i<bombCount; i++)
		p.drawPixmap(bomb[i]->x, bomb[i]->y, bombPic);
	for (int i=0; i< maxBombs-bombCount; i++)
		p.drawPixmap(240 - (1+i)*(bombPic.width()+3), 3, bombPic);

	// Numbers
	for (int i=0; i<numberCount; i++) {
		QString text;
		text.sprintf("%d", int(number[i]->val));
		p.drawText(number[i]->x, number[i]->y, text);
	}
	
	// Paused
	if (! mainTimer->isActive())
	    p.drawText(100, 135, "Paused");

	// Screen update
	QPainter final(this);
	final.drawPixmap(0, 0, *buffer);
}




