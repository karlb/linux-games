#ifndef HIGHSCORE_H
#define HIGHSCORE_H

#include <qpe/config.h>
#include <qwidget.h>

class HighScore : private Config
{
	QString name[10];
	int score[10];
	QWidget *parent;
	QString *appName;

public:

	HighScore(QWidget *parent, char *appName);
	~HighScore();
	void addScore(int score);
	void writeScore();
	void showScore();
};


#endif