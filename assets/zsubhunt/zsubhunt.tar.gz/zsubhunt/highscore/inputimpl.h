#ifndef INPUTIMPL_H
#define INPUTIMPL_H
#include "input.h"
#include "qstring.h"

class inputImpl : public input
{ 
    Q_OBJECT

public:
    inputImpl( QWidget* parent = 0, QString *newname = NULL, const char* name = 0, WFlags fl = 0 );
    ~inputImpl();

public slots:
    void setName(const QString&);

private:
    QString *namep;

};

#endif // INPUTIMPL_H
