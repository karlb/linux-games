#ifndef ZNUMBERS_WINDOW_H
#define ZNUMBERS_WINDOW_H
#include <qmainwindow.h>
#include "board.h"

class AppWindow : public QMainWindow
{
	Q_OBJECT
public:
	AppWindow( QWidget* parent = 0, const char* name = 0, WFlags f = WType_TopLevel );

private slots:
	void menuSelected(int);

private:

	enum MenuItems
	{
		PAUSE_GAME,
		UNPAUSE_GAME,
		EXIT,
		ABOUT,
		RULES,
		HIGHSCORE1,
		HIGHSCORE2,
		HIGHSCORE3,
		
		LEVELNUM
	};

	QPopupMenu* appMenu;
	QPopupMenu* levelMenu;

	Board *board;
};

#endif
