#ifndef BOARD_H
#define BOARD_H

#include <qwidget.h>
#include <qbitmap.h>
#include <qtimer.h>
#include <qpoint.h>
#include <qlist.h>
#include <qtimer.h>
#include <qpixmap.h>
#include <qevent.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>

#include "highscore/highscore.h"

class Sub {
	public:
	
	float x, y, speed;
	
	Sub(int xpos, int ypos, float startSpeed) {
		x = xpos;
		y = ypos;
		speed = startSpeed;
	}
};

class Bomb {
	public:
	
	float x, y, speed;
	
	Bomb(int xpos, int ypos, float startSpeed) {
		x = xpos;
		y = ypos;
		speed = startSpeed;
	}
};

class Number {
	public:

	float x, y, speed, val, time;

	Number(int xpos, int ypos, int value, int remTime) {
		x = xpos;
		y = ypos;
		val = value;
		time = remTime;
		speed = -20;
	}
};

class Board : public QWidget
{
	Q_OBJECT

public:
	Board(QWidget* parent=0, const char* name=0, WFlags f=0 );
	~Board();
	void startLevel(int difficulty);
	void start();
	void stop();
	HighScore *highScore[3];
	
protected:
	void paintEvent ( QPaintEvent *pe);
	void keyPressEvent ( QKeyEvent *e);
	void keyReleaseEvent ( QKeyEvent *e);

private slots: 
	void gameLogic();
	void newSub();

private:
	QPixmap blockPic[5], movedPic[5], waterPic[8], skyPic, subPic, destroyerPic, bombPic, livesPic, *buffer;
	int numberCount, subCount, bombCount, score, levelNum, lives, difficulty;
	Sub *sub[20];
	Bomb *bomb[20];
	Number *number[20];
	float interval, destroyerX, subInterval, waterCount;
	bool fault, lost, leftPressed, rightPressed;
	QTimer *newBlockTimer, *selectTimer, *newSubTimer, *mainTimer;

	bool finished();
	void newBomb();
	QPixmap loadPixmap(char *file);
};

#endif
